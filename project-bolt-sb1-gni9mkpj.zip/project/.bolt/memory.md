# Project memory

## Product intent & audience

- **LevelUp** — a gamified web app (likely habit/task/progress tracking) with XP granting mechanics.
- Built with Vite + React; backend on Supabase (database + auth).
- User requested standalone portfolio/case-study HTML, a project `AUDIT.md`, and a `README.md` for GitHub publishing.

## Brand personality & voice

- Developer-facing, production-minded tone.
- Audit language is security-aware and precise (RLS, owner-scoped policies, server-side logic).

## Visual design & UX direction

- Dark hero with **green-cyan gradient** as the app's signature look.
- Portfolio page: self-contained single HTML, stats, feature cards, tech-stack chips, "how it's built" section, CTA.
- Component patterns inferred: hero + stat row + card grid + chip list + sectioned narrative.

## Decisions, constraints & rationale

- **Stack:** Vite + React + Tailwind CSS + Lucide React + Supabase. No extra UI/icon packages.
- **Path alias:** `@/` → `src/` (per `.bolt/prompt`).
- **Security:** Row-level security and owner-scoped policies verified passing.
- **Hardening recs (low severity):** move XP granting server-side (and similar client-trusted mutations) to Supabase RPC/edge functions.
- **Publishing:** portfolio `index.html` works at repo root or `docs/` for GitHub Pages; README clone URL needs `YOUR_USERNAME` replaced.

## Open questions & assumptions

- Exact feature set of LevelUp beyond gamification/XP is inferred from audit, not fully enumerated.
- Supabase project keys and DB setup SQL are referenced in README but not captured here.
- Deployment target assumed to be GitHub Pages (static) for the portfolio; app itself may need Supabase env vars on host.