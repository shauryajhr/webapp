# LevelUp — Project Audit

**Date:** 2026-11-19
**App:** LevelUp — Gamified Fitness & Personal Growth RPG
**Stack:** React 18 · TypeScript · Vite · Tailwind CSS · Supabase (Postgres + Auth)

---

## 1. Project Overview

LevelUp is a full-stack, multi-user web app that gamifies fitness and personal growth.
Users earn XP for real-world actions (workouts, sleep, hydration, study), level up five
RPG stats (Strength, Health, Discipline, Energy, Consistency), complete auto-generated
daily quests, and receive rule-based coaching insights derived from their logged data.

### App structure

| Screen | Purpose |
|---|---|
| Auth | Email/password sign-up and sign-in |
| Onboarding | First-run profile setup (goals, sleep target, available time) that seeds the RPG character |
| Dashboard | XP bar, level, stats, daily quests, coach insights, motivational messages |
| Workout | Weekly training split, guided workout execution, workout logging |
| Schedule | Daily life schedule items |
| Growth | Goals, habits, body metrics, analytics (line/bar charts + consistency heatmap) |
| Profile | Account settings and progress overview |

---

## 2. Architecture

- **Front end:** Single-page React app (Vite + TypeScript + Tailwind). Path alias `@/` → `src/`.
- **Auth:** Supabase Auth (email/password). Session state handled via `onAuthStateChange`
  with a deadlock guard in `src/lib/auth.tsx`.
- **Database:** Supabase Postgres, 12 tables, RLS on every table.
- **Domain logic (pure TypeScript, fully unit-testable):**
  - `src/lib/gamification.ts` — XP rewards table, stat boosts, level curve, quest generator, badge thresholds, weight/consistency projections.
  - `src/lib/coach.ts` — rule-based coaching engine producing prioritized insights (recovery, sleep, nutrition, hydration, streaks, goals, energy).
  - `src/lib/utils.ts` — streaks, consistency score, level math.
- **Charts:** Custom SVG components (`src/components/charts/`) — no chart library dependency.
- **Demo data:** `src/lib/demoData.ts` provides a populated experience for new accounts.

### Database tables

`profiles`, `workouts`, `workout_logs`, `daily_logs`, `goals`, `habits`, `habit_logs`,
`quests`, `schedule_items`, `body_metrics`, `badges`, `ai_insights`

---

## 3. Security Audit

### 3.1 Row-Level Security — PASS

- RLS is enabled on all 12 tables.
- Each table has four separate owner-scoped policies (SELECT / INSERT / UPDATE / DELETE),
  each scoped `TO authenticated` and keyed on `auth.uid() = user_id` (or `id` for `profiles`).
- `profiles.id` references `auth.users(id) ON DELETE CASCADE` — no orphaned profiles.
- All `user_id` columns default to `auth.uid()`, preventing client-side user spoofing on insert.
- `daily_logs` has a `UNIQUE(user_id, date)` constraint — one check-in per user per day.

### 3.2 Auth — PASS

- No custom auth tables; Supabase Auth manages credentials and sessions.
- The app gates every screen behind `session` and `onboarding_complete`.
- No secrets in client code; only the public anon key is exposed to the browser (by design).

### 3.3 Findings & recommendations

| # | Severity | Finding | Recommendation |
|---|---|---|---|
| 1 | Low | `profiles` UPDATE policy allows users to edit their own `xp`, `level`, and stat columns directly via API/SDK, bypassing the XP engine. | Move XP/stat mutations into a Postgres function (`SECURITY DEFINER`) or Supabase Edge Function so the client can only request actions, not set values. |
| 2 | Low | `badges` rows are client-inserted; badge award logic lives in the browser. | Award badges server-side (trigger or edge function) to prevent arbitrary badge claims. |
| 3 | Low | `daily_logs` numeric fields (steps, calories, water) accept any value a client sends. | Add `CHECK` constraints (e.g. `steps BETWEEN 0 AND 100000`) to bound outliers. |
| 4 | Info | Coaching insights are computed client-side from raw logs — fine for a personal app, and it keeps compute free. | For AI-generated insights, proxy any third-party API through a Supabase Edge Function so API keys never reach the browser. |
| 5 | Info | No rate limiting on auth endpoints. | Supabase applies default rate limits; consider tightening for public launches. |

No critical or high-severity issues found. All data access is properly scoped to the
authenticated owner; the findings above are hardening opportunities, not vulnerabilities
actively exploitable against other users.

---

## 4. Code Quality

**Strengths**
- Clean separation: pages / components / lib / types.
- Domain logic is pure and side-effect free — easy to test.
- Typed end-to-end (`src/types/index.ts`).
- Zero-dependency custom charts keep the bundle small.
- Consistent policy naming and schema conventions across all migrations.

**Areas to improve**
- No test suite yet — the pure functions in `gamification.ts` and `coach.ts` are ideal first targets.
- `src/pages/Workout.tsx` and `Dashboard.tsx` are the largest files; could be split as features grow.
- No CI pipeline (lint / typecheck / build) — GitHub Actions workflow would be a quick win.

---

## 5. Deployment Notes

- Static build via `npm run build` → `dist/`. Hosts on Vercel, Netlify, or GitHub Pages (with SPA fallback; a `_redirects` file is already present in `dist/`).
- Required environment: `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY`.
- Database migrations live in `supabase/migrations/` and can be applied with the Supabase CLI or the Supabase dashboard.

---

## 6. Verdict

LevelUp is a well-structured, security-conscious full-stack project. Data isolation is
correctly enforced at the database level, the game logic is cleanly factored into pure
functions, and the app ships a complete user journey (auth → onboarding → daily loop →
progress). The main next steps are server-authoritative XP/badge granting, a test suite,
and CI.
