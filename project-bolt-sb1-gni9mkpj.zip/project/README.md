# ⚡ LevelUp — Don't just track your life. Level it up.

A full-stack fitness and personal-growth app that turns self-improvement into an RPG.
Earn XP for real-world actions, level up five character stats, complete daily quests,
and get personal coaching insights — backed by a secure Postgres database.

![Status](https://img.shields.io/badge/status-active-brightgreen) ![React](https://img.shields.io/badge/React-18-blue) ![TypeScript](https://img.shields.io/badge/TypeScript-5-blue) ![Supabase](https://img.shields.io/badge/Backend-Supabase-green)

## Features

- **RPG progression** — Workouts, sleep, water and study sessions earn XP and boost five stats: Strength, Health, Discipline, Energy, Consistency.
- **Daily quests** — An auto-generated quest board each day, with bonus XP for a full clear.
- **Personal coach** — A rule-based engine analyzes your last 7–14 days of logs (sleep, streaks, protein, hydration, energy) and produces prioritized insights.
- **Workout system** — Weekly training split with guided exercises and full history logging.
- **Goals & habits** — Goal tracking with deadlines and progress, habit tracker with streaks.
- **Analytics** — Custom SVG line/bar charts and a GitHub-style consistency heatmap, plus weight projections based on consistency.
- **Badges** — Achievement milestones: first workout, 7-day streak, 100 workouts, and more.

## Tech Stack

| Layer | Technology |
|---|---|
| Front end | React 18, TypeScript, Vite, Tailwind CSS |
| Icons | Lucide React |
| Charts | Custom SVG components (zero chart dependencies) |
| Backend | Supabase (Postgres, Auth, Row-Level Security) |

## Getting Started

### Prerequisites

- Node.js 18+
- A [Supabase](https://supabase.com) project (free tier works)

### Setup

1. **Clone and install**

   ```bash
   git clone https://github.com/YOUR_USERNAME/levelup.git
   cd levelup
   npm install
   ```

2. **Configure environment variables** — create a `.env` file in the project root:

   ```env
   VITE_SUPABASE_URL=your-supabase-project-url
   VITE_SUPABASE_ANON_KEY=your-supabase-anon-key
   ```

   Both values are in your Supabase dashboard under **Settings → API**.

3. **Apply the database schema** — run the SQL in `supabase/migrations/` against your
   Supabase project (SQL Editor → paste → run). This creates all 12 tables with
   row-level security enabled and owner-scoped policies on every table.

4. **Run the app**

   ```bash
   npm run dev
   ```

   Open the local URL, create an account, and complete onboarding to generate your RPG profile.

## Scripts

| Command | Description |
|---|---|
| `npm run dev` | Start the dev server |
| `npm run build` | Production build to `dist/` |
| `npm run preview` | Preview the production build locally |
| `npm run lint` | Lint with ESLint |
| `npm run typecheck` | Type-check with TypeScript |

## Project Structure

```
src/
├── components/          # Auth, Onboarding, BottomNav, charts, UI primitives
├── pages/               # Dashboard, Workout, Schedule, Growth, Profile
├── lib/                 # Domain logic
│   ├── auth.tsx         #   Supabase session provider
│   ├── gamification.ts  #   XP engine, quests, badges, projections
│   ├── coach.ts         #   Rule-based coaching insights
│   ├── demoData.ts      #   Sample data for new accounts
│   └── utils.ts         #   Streaks, consistency score, level math
└── types/               # Shared TypeScript types
supabase/
└── migrations/          # Full database schema + RLS policies
```

## Database & Security

- **12 tables:** profiles, workouts, workout_logs, daily_logs, goals, habits, habit_logs, quests, schedule_items, body_metrics, badges, ai_insights.
- **Row-Level Security on every table** — four owner-scoped policies each, so users can only read and write their own rows.
- Sessions are handled by Supabase Auth; no custom credential storage.

See [AUDIT.md](AUDIT.md) for the full security and code-quality review.

## Deployment

The app is a static SPA. After `npm run build`, deploy `dist/` to Vercel, Netlify, or
GitHub Pages (add an SPA fallback so deep links work). Set `VITE_SUPABASE_URL` and
`VITE_SUPABASE_ANON_KEY` in your host's environment settings.

## License

MIT
