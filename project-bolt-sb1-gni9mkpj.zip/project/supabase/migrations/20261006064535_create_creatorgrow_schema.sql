/*
# CreatorGrow: Core Schema

## Overview
Creates the full database schema for CreatorGrow, a creator growth platform.
This is a multi-user app with authentication — each creator sees only their own data.

## New Tables

1. **profiles** — extends auth.users with creator-specific fields
   - id (uuid, PK, references auth.users)
   - niche, target_audience, content_style (text)
   - platforms (text array)
   - follower_count, posting_frequency, main_goal, weekly_hours (text/numeric onboarding answers)
   - onboarding_complete (boolean, default false)
   - growth_score (integer, default 0)
   - avatar_url, display_name (text)

2. **posts** — content calendar items
   - id, user_id, title, platform, content_type, status (draft/planned/published/missed)
   - scheduled_date (date), hook, caption, cta, hashtags, notes
   - created_at, updated_at

3. **analytics_daily** — daily analytics snapshots
   - id, user_id, date
   - followers, follower_growth, engagement_rate, reach, views
   - likes, comments, shares, saves, profile_visits
   - best_post_type (text)

4. **content_ideas** — saved AI-generated ideas
   - id, user_id, title, platform, content_type, hook, caption, cta, hashtags
   - script, trending_format, status (new/saved/used)
   - created_at

5. **goals** — user goals with progress tracking
   - id, user_id, type, title, target_value, current_value, unit, deadline
   - status (active/completed/abandoned)
   - created_at

6. **badges** — gamification badges
   - id, user_id, badge_type, name, description, earned_at

## Security
- RLS enabled on every table
- Owner-scoped CRUD policies (SELECT/INSERT/UPDATE/DELETE)
- All owner columns default to auth.uid()
- Only authenticated users can access data
*/