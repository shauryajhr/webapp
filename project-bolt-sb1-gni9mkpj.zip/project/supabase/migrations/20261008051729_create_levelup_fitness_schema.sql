/*
# LevelUp: Fitness & Personal Growth RPG Schema

## Overview
Creates the full database schema for "LevelUp" — a fitness, productivity, and personal growth
tracking app that gamifies self-improvement with RPG-style character progression, XP, levels,
streaks, quests, and an AI coach. This is a multi-user app with authentication.

## New Tables

1. **profiles** — extends auth.users with RPG character data
   - name, age, height_cm, weight_kg, fitness_goal, activity_level, experience_level
   - daily_available_time, sleep_target_hours, personal_goals
   - xp, level, onboarding_complete
   - RPG stats: strength, health, discipline, energy, consistency (0-100)

2. **workouts** — weekly workout schedule entries
   - day_of_week (0-6), workout_type, title, exercises (jsonb array), duration_min, difficulty, calories

3. **workout_logs** — completed workout records
   - workout_type, exercises_completed, duration_min, calories_burned, xp_earned, date

4. **daily_logs** — daily check-in and tracking data (one per day per user)
   - date, steps, water_liters, sleep_hours, calories_eaten, protein_g, carbs_g, fats_g
   - energy_level (1-3), mood (1-5), stress_level (1-3)
   - study_hours, screen_time_hours, meditation_minutes
   - workout_completed (boolean), daily_quest_completed (boolean)

5. **goals** — user goals with progress tracking
   - type, title, target_value, current_value, unit, deadline, status, streak

6. **habits** — habit definitions and tracking
   - name, icon, frequency, target_count, current_count, streak, active

7. **habit_logs** — daily habit completion records
   - habit_id, date, completed

8. **quests** — auto-generated daily quests
   - date, title, xp_reward, completed, quest_type

9. **schedule_items** — daily life schedule entries
   - day_of_week, time, title, category, duration_min, sortable

10. **body_metrics** — weight and measurement tracking over time
    - date, weight_kg, chest_cm, waist_cm, arm_cm, pushups_max, notes

11. **badges** — earned achievement badges
    - badge_type, name, description, icon

12. **ai_insights** — AI coach messages stored for history
    - insight, insight_type, date

## Security
- RLS enabled on every table
- Owner-scoped CRUD policies (4 per table: SELECT/INSERT/UPDATE/DELETE)
- All user_id columns default to auth.uid()
- Only authenticated users can access data
*/

-- ============================================
-- PROFILES
-- ============================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  name text,
  age integer,
  height_cm numeric,
  weight_kg numeric,
  fitness_goal text,
  activity_level text,
  experience_level text,
  daily_available_time text,
  sleep_target_hours numeric DEFAULT 7,
  personal_goals text,
  xp integer NOT NULL DEFAULT 0,
  level integer NOT NULL DEFAULT 1,
  onboarding_complete boolean NOT NULL DEFAULT false,
  strength integer NOT NULL DEFAULT 10,
  health integer NOT NULL DEFAULT 10,
  discipline integer NOT NULL DEFAULT 10,
  energy integer NOT NULL DEFAULT 10,
  consistency integer NOT NULL DEFAULT 10,
  life_level integer NOT NULL DEFAULT 10,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
TO authenticated USING (auth.uid() = id);

-- ============================================
-- WORKOUTS
-- ============================================
CREATE TABLE IF NOT EXISTS workouts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  day_of_week integer NOT NULL DEFAULT 0,
  workout_type text NOT NULL DEFAULT 'Push',
  title text NOT NULL,
  exercises jsonb NOT NULL DEFAULT '[]',
  duration_min integer DEFAULT 45,
  difficulty text DEFAULT 'Intermediate',
  calories integer DEFAULT 300,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE workouts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_workouts" ON workouts;
CREATE POLICY "select_own_workouts" ON workouts FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_workouts" ON workouts;
CREATE POLICY "insert_own_workouts" ON workouts FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_workouts" ON workouts;
CREATE POLICY "update_own_workouts" ON workouts FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_workouts" ON workouts;
CREATE POLICY "delete_own_workouts" ON workouts FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- WORKOUT_LOGS
-- ============================================
CREATE TABLE IF NOT EXISTS workout_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL,
  workout_type text NOT NULL,
  exercises_completed jsonb DEFAULT '[]',
  duration_min integer DEFAULT 0,
  calories_burned integer DEFAULT 0,
  xp_earned integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE workout_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_workout_logs" ON workout_logs;
CREATE POLICY "select_own_workout_logs" ON workout_logs FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_workout_logs" ON workout_logs;
CREATE POLICY "insert_own_workout_logs" ON workout_logs FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_workout_logs" ON workout_logs;
CREATE POLICY "delete_own_workout_logs" ON workout_logs FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- DAILY_LOGS
-- ============================================
CREATE TABLE IF NOT EXISTS daily_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL,
  steps integer DEFAULT 0,
  water_liters numeric DEFAULT 0,
  sleep_hours numeric DEFAULT 0,
  calories_eaten integer DEFAULT 0,
  protein_g integer DEFAULT 0,
  carbs_g integer DEFAULT 0,
  fats_g integer DEFAULT 0,
  energy_level integer DEFAULT 2,
  mood integer DEFAULT 3,
  stress_level integer DEFAULT 2,
  study_hours numeric DEFAULT 0,
  screen_time_hours numeric DEFAULT 0,
  meditation_minutes integer DEFAULT 0,
  workout_completed boolean DEFAULT false,
  daily_quests_completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, date)
);

ALTER TABLE daily_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_daily_logs" ON daily_logs;
CREATE POLICY "select_own_daily_logs" ON daily_logs FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_daily_logs" ON daily_logs;
CREATE POLICY "insert_own_daily_logs" ON daily_logs FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_daily_logs" ON daily_logs;
CREATE POLICY "update_own_daily_logs" ON daily_logs FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_daily_logs" ON daily_logs;
CREATE POLICY "delete_own_daily_logs" ON daily_logs FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- GOALS
-- ============================================
CREATE TABLE IF NOT EXISTS goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  target_value numeric NOT NULL,
  current_value numeric DEFAULT 0,
  unit text DEFAULT '',
  deadline date,
  streak integer DEFAULT 0,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE goals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_goals" ON goals;
CREATE POLICY "select_own_goals" ON goals FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_goals" ON goals;
CREATE POLICY "insert_own_goals" ON goals FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_goals" ON goals;
CREATE POLICY "update_own_goals" ON goals FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_goals" ON goals;
CREATE POLICY "delete_own_goals" ON goals FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- HABITS
-- ============================================
CREATE TABLE IF NOT EXISTS habits (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  name text NOT NULL,
  icon text DEFAULT '✅',
  frequency text DEFAULT 'daily',
  target_count integer DEFAULT 1,
  current_count integer DEFAULT 0,
  streak integer DEFAULT 0,
  active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE habits ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_habits" ON habits;
CREATE POLICY "select_own_habits" ON habits FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_habits" ON habits;
CREATE POLICY "insert_own_habits" ON habits FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_habits" ON habits;
CREATE POLICY "update_own_habits" ON habits FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_habits" ON habits;
CREATE POLICY "delete_own_habits" ON habits FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- HABIT_LOGS
-- ============================================
CREATE TABLE IF NOT EXISTS habit_logs (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  habit_id uuid REFERENCES habits(id) ON DELETE CASCADE,
  date date NOT NULL,
  completed boolean DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE habit_logs ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_habit_logs" ON habit_logs;
CREATE POLICY "select_own_habit_logs" ON habit_logs FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_habit_logs" ON habit_logs;
CREATE POLICY "insert_own_habit_logs" ON habit_logs FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_habit_logs" ON habit_logs;
CREATE POLICY "delete_own_habit_logs" ON habit_logs FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- QUESTS
-- ============================================
CREATE TABLE IF NOT EXISTS quests (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL,
  title text NOT NULL,
  quest_type text NOT NULL DEFAULT 'general',
  xp_reward integer NOT NULL DEFAULT 50,
  completed boolean NOT NULL DEFAULT false,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE quests ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_quests" ON quests;
CREATE POLICY "select_own_quests" ON quests FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_quests" ON quests;
CREATE POLICY "insert_own_quests" ON quests FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_quests" ON quests;
CREATE POLICY "update_own_quests" ON quests FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_quests" ON quests;
CREATE POLICY "delete_own_quests" ON quests FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- SCHEDULE_ITEMS
-- ============================================
CREATE TABLE IF NOT EXISTS schedule_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  day_of_week integer NOT NULL DEFAULT 0,
  time text NOT NULL,
  title text NOT NULL,
  category text DEFAULT 'general',
  duration_min integer DEFAULT 60,
  sort_order integer DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE schedule_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_schedule" ON schedule_items;
CREATE POLICY "select_own_schedule" ON schedule_items FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_schedule" ON schedule_items;
CREATE POLICY "insert_own_schedule" ON schedule_items FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_schedule" ON schedule_items;
CREATE POLICY "update_own_schedule" ON schedule_items FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_schedule" ON schedule_items;
CREATE POLICY "delete_own_schedule" ON schedule_items FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- BODY_METRICS
-- ============================================
CREATE TABLE IF NOT EXISTS body_metrics (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL,
  weight_kg numeric,
  chest_cm numeric,
  waist_cm numeric,
  arm_cm numeric,
  pushups_max integer,
  notes text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, date)
);

ALTER TABLE body_metrics ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_body_metrics" ON body_metrics;
CREATE POLICY "select_own_body_metrics" ON body_metrics FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_body_metrics" ON body_metrics;
CREATE POLICY "insert_own_body_metrics" ON body_metrics FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_body_metrics" ON body_metrics;
CREATE POLICY "update_own_body_metrics" ON body_metrics FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_body_metrics" ON body_metrics;
CREATE POLICY "delete_own_body_metrics" ON body_metrics FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- BADGES
-- ============================================
CREATE TABLE IF NOT EXISTS badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  badge_type text NOT NULL,
  name text NOT NULL,
  description text,
  icon text DEFAULT '🏆',
  earned_at timestamptz DEFAULT now()
);

ALTER TABLE badges ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_badges" ON badges;
CREATE POLICY "select_own_badges" ON badges FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_badges" ON badges;
CREATE POLICY "insert_own_badges" ON badges FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_badges" ON badges;
CREATE POLICY "delete_own_badges" ON badges FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- AI_INSIGHTS
-- ============================================
CREATE TABLE IF NOT EXISTS ai_insights (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  insight text NOT NULL,
  insight_type text DEFAULT 'general',
  date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE ai_insights ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_insights" ON ai_insights;
CREATE POLICY "select_own_insights" ON ai_insights FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_insights" ON ai_insights;
CREATE POLICY "insert_own_insights" ON ai_insights FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_insights" ON ai_insights;
CREATE POLICY "delete_own_insights" ON ai_insights FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- INDEXES
-- ============================================
CREATE INDEX IF NOT EXISTS idx_workouts_user ON workouts(user_id, day_of_week);
CREATE INDEX IF NOT EXISTS idx_workout_logs_user_date ON workout_logs(user_id, date);
CREATE INDEX IF NOT EXISTS idx_daily_logs_user_date ON daily_logs(user_id, date);
CREATE INDEX IF NOT EXISTS idx_goals_user ON goals(user_id);
CREATE INDEX IF NOT EXISTS idx_habits_user ON habits(user_id);
CREATE INDEX IF NOT EXISTS idx_habit_logs_user_date ON habit_logs(user_id, date);
CREATE INDEX IF NOT EXISTS idx_quests_user_date ON quests(user_id, date);
CREATE INDEX IF NOT EXISTS idx_schedule_user_day ON schedule_items(user_id, day_of_week);
CREATE INDEX IF NOT EXISTS idx_body_metrics_user_date ON body_metrics(user_id, date);
CREATE INDEX IF NOT EXISTS idx_badges_user ON badges(user_id);
CREATE INDEX IF NOT EXISTS idx_insights_user_date ON ai_insights(user_id, date);