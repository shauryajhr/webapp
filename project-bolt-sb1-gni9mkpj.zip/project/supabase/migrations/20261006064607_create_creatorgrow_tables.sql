/*
# CreatorGrow: Tables and Policies

## New Tables

1. **profiles** — creator profile extending auth.users
   - niche, target_audience, content_style, platforms, onboarding answers
   - growth_score, avatar_url, display_name, onboarding_complete

2. **posts** — content calendar items (draft/planned/published/missed)
   - scheduled_date, hook, caption, cta, hashtags, platform, content_type

3. **analytics_daily** — daily metric snapshots
   - followers, growth, engagement_rate, reach, views, likes, comments, shares, saves, visits

4. **content_ideas** — saved AI-generated content ideas
   - title, platform, hook, caption, cta, hashtags, script, trending_format, status

5. **goals** — user goals with progress (active/completed/abandoned)
   - type, target_value, current_value, unit, deadline

6. **badges** — gamification milestones earned

## Security
- RLS enabled on all tables
- Owner-scoped CRUD: 4 policies per table (SELECT/INSERT/UPDATE/DELETE)
- All user_id columns default to auth.uid()
- TO authenticated only — sign-in required
*/

-- ============================================
-- PROFILES
-- ============================================
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  display_name text,
  avatar_url text,
  niche text,
  target_audience text,
  content_style text,
  platforms text[] DEFAULT '{}',
  follower_count integer DEFAULT 0,
  posting_frequency text,
  main_goal text,
  weekly_hours text,
  onboarding_complete boolean NOT NULL DEFAULT false,
  growth_score integer DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_profile" ON profiles;
CREATE POLICY "select_own_profile" ON profiles FOR SELECT
TO authenticated USING (auth.uid() = id);

DROP POLICY IF EXISTS "insert_own_profile" ON profiles;
CREATE POLICY "insert_own_profile" ON profiles FOR INSERT
TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "update_own_profile" ON profiles;
CREATE POLICY "update_own_profile" ON profiles FOR UPDATE
TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "delete_own_profile" ON profiles;
CREATE POLICY "delete_own_profile" ON profiles FOR DELETE
TO authenticated USING (auth.uid() = id);

-- ============================================
-- POSTS
-- ============================================
CREATE TABLE IF NOT EXISTS posts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  platform text DEFAULT 'Instagram',
  content_type text DEFAULT 'Reel',
  status text NOT NULL DEFAULT 'planned',
  scheduled_date date,
  hook text,
  caption text,
  cta text,
  hashtags text,
  notes text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE posts ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_posts" ON posts;
CREATE POLICY "select_own_posts" ON posts FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_posts" ON posts;
CREATE POLICY "insert_own_posts" ON posts FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_posts" ON posts;
CREATE POLICY "update_own_posts" ON posts FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_posts" ON posts;
CREATE POLICY "delete_own_posts" ON posts FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- ANALYTICS_DAILY
-- ============================================
CREATE TABLE IF NOT EXISTS analytics_daily (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  date date NOT NULL,
  followers integer DEFAULT 0,
  follower_growth numeric DEFAULT 0,
  engagement_rate numeric DEFAULT 0,
  reach integer DEFAULT 0,
  views integer DEFAULT 0,
  likes integer DEFAULT 0,
  comments integer DEFAULT 0,
  shares integer DEFAULT 0,
  saves integer DEFAULT 0,
  profile_visits integer DEFAULT 0,
  best_post_type text,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, date)
);

ALTER TABLE analytics_daily ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_analytics" ON analytics_daily;
CREATE POLICY "select_own_analytics" ON analytics_daily FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_analytics" ON analytics_daily;
CREATE POLICY "insert_own_analytics" ON analytics_daily FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_analytics" ON analytics_daily;
CREATE POLICY "update_own_analytics" ON analytics_daily FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_analytics" ON analytics_daily;
CREATE POLICY "delete_own_analytics" ON analytics_daily FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- CONTENT_IDEAS
-- ============================================
CREATE TABLE IF NOT EXISTS content_ideas (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL,
  platform text DEFAULT 'Instagram',
  content_type text DEFAULT 'Reel',
  hook text,
  caption text,
  cta text,
  hashtags text,
  script text,
  trending_format text,
  status text NOT NULL DEFAULT 'new',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE content_ideas ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_ideas" ON content_ideas;
CREATE POLICY "select_own_ideas" ON content_ideas FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_ideas" ON content_ideas;
CREATE POLICY "insert_own_ideas" ON content_ideas FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_ideas" ON content_ideas;
CREATE POLICY "update_own_ideas" ON content_ideas FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_ideas" ON content_ideas;
CREATE POLICY "delete_own_ideas" ON content_ideas FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- GOALS
-- ============================================
CREATE TABLE IF NOT EXISTS goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  type text NOT NULL,
  title text NOT NULL,
  target_value numeric NOT NULL,
  current_value numeric DEFAULT 0,
  unit text DEFAULT '',
  deadline date,
  status text NOT NULL DEFAULT 'active',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE goals ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_goals" ON goals;
CREATE POLICY "select_own_goals" ON goals FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_goals" ON goals;
CREATE POLICY "insert_own_goals" ON goals FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "update_own_goals" ON goals;
CREATE POLICY "update_own_goals" ON goals FOR UPDATE
TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_goals" ON goals;
CREATE POLICY "delete_own_goals" ON goals FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- BADGES
-- ============================================
CREATE TABLE IF NOT EXISTS badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  badge_type text NOT NULL,
  name text NOT NULL,
  description text,
  earned_at timestamptz DEFAULT now()
);

ALTER TABLE badges ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "select_own_badges" ON badges;
CREATE POLICY "select_own_badges" ON badges FOR SELECT
TO authenticated USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "insert_own_badges" ON badges;
CREATE POLICY "insert_own_badges" ON badges FOR INSERT
TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "delete_own_badges" ON badges;
CREATE POLICY "delete_own_badges" ON badges FOR DELETE
TO authenticated USING (auth.uid() = user_id);

-- ============================================
-- INDEXES
-- ============================================
CREATE INDEX IF NOT EXISTS idx_posts_user_date ON posts(user_id, scheduled_date);
CREATE INDEX IF NOT EXISTS idx_analytics_user_date ON analytics_daily(user_id, date);
CREATE INDEX IF NOT EXISTS idx_ideas_user ON content_ideas(user_id);
CREATE INDEX IF NOT EXISTS idx_goals_user ON goals(user_id);
CREATE INDEX IF NOT EXISTS idx_badges_user ON badges(user_id);