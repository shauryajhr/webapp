import { useEffect, useState, useRef } from 'react';
import { Dumbbell, Play, Pause, SkipForward, X, Check, Plus, Clock, Flame, ChevronLeft, ChevronRight, Zap } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { Card, Badge } from '@/components/ui/Card';
import { cn, getDayShort, todayDayOfWeek, todayStr } from '@/lib/utils';
import { applyXpGain } from '@/lib/gamification';
import type { Workout, Exercise, WorkoutLog, DailyLog } from '@/types';

export default function WorkoutPage() {
  const { profile, refreshProfile } = useAuth();
  const [workouts, setWorkouts] = useState<Workout[]>([]);
  const [selectedDay, setSelectedDay] = useState(todayDayOfWeek());
  const [workoutMode, setWorkoutMode] = useState<Workout | null>(null);
  const [loading, setLoading] = useState(true);
  const [celebration, setCelebration] = useState<{ xp: number; statChanges: Record<string, number>; streak: number } | null>(null);

  useEffect(() => {
    if (!profile) return;
    supabase.from('workouts').select('*').eq('user_id', profile.id).order('day_of_week', { ascending: true })
      .then(({ data }) => { setWorkouts(data as Workout[] || []); setLoading(false); });
  }, [profile]);

  const dayWorkout = workouts.find(w => w.day_of_week === selectedDay);
  const days = [1, 2, 3, 4, 5, 6, 0];

  if (celebration) {
    return <CelebrationScreen data={celebration} onDone={() => { setCelebration(null); setWorkoutMode(null); }} />;
  }

  if (workoutMode) {
    return <WorkoutMode workout={workoutMode} onExit={() => setWorkoutMode(null)} onComplete={async (exercisesCompleted, durationMin) => {
      if (!profile) return;
      const xpResult = applyXpGain(profile, 100 + Math.floor(durationMin / 10) * 10, { strength: 3, discipline: 2, energy: 1 });
      await supabase.from('profiles').update(xpResult.profile).eq('id', profile.id);

      const today = todayStr();
      await supabase.from('workout_logs').insert({
        user_id: profile.id, date: today, workout_type: workoutMode.workout_type,
        exercises_completed: exercisesCompleted as unknown as Record<string, unknown>[],
        duration_min: durationMin, calories_burned: workoutMode.calories, xp_earned: 100 + Math.floor(durationMin / 10) * 10,
      });

      const { data: dl } = await supabase.from('daily_logs').select('*').eq('user_id', profile.id).eq('date', today).maybeSingle();
      if (dl) {
        await supabase.from('daily_logs').update({ workout_completed: true }).eq('id', dl.id);
      } else {
        await supabase.from('daily_logs').insert({ user_id: profile.id, date: today, workout_completed: true });
      }

      // Mark workout quest as completed
      const { data: quest } = await supabase.from('quests').select('*').eq('user_id', profile.id).eq('date', today).eq('quest_type', 'workout').maybeSingle();
      if (quest && !quest.completed) {
        await supabase.from('quests').update({ completed: true }).eq('id', quest.id);
      }

      await refreshProfile();
      setCelebration({ xp: 100 + Math.floor(durationMin / 10) * 10, statChanges: { Strength: 3, Discipline: 2, Energy: 1 }, streak: 7 });
    }} />;
  }

  if (loading) return <div className="space-y-4 animate-pulse"><div className="h-10 w-60 bg-white/[0.04] rounded-xl" /><div className="h-80 bg-white/[0.04] rounded-2xl" /></div>;

  return (
    <div className="space-y-5 max-w-3xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-white">Workout</h1>
        <p className="text-sm text-gray-400 mt-1">Your weekly training schedule</p>
      </div>

      {/* Day selector */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {days.map(dow => {
          const w = workouts.find(w => w.day_of_week === dow);
          const isToday = dow === todayDayOfWeek();
          const isSelected = dow === selectedDay;
          return (
            <button key={dow} onClick={() => setSelectedDay(dow)}
              className={cn('flex flex-col items-center gap-1 px-4 py-3 rounded-2xl min-w-[70px] transition-all border',
                isSelected ? 'bg-emerald-400/10 border-emerald-400/30' : 'bg-white/[0.03] border-white/[0.06] hover:bg-white/[0.06]')}>
              <span className={cn('text-xs font-bold', isSelected ? 'text-emerald-400' : 'text-gray-400')}>{getDayShort(dow)}</span>
              <span className="text-lg">{w ? w.workout_type === 'Recovery' ? '🧘' : w.workout_type === 'Cardio' ? '🏃' : '🏋️' : '😴'}</span>
              {isToday && <span className="w-1 h-1 rounded-full bg-emerald-400" />}
            </button>
          );
        })}
      </div>

      {/* Workout detail */}
      {dayWorkout ? (
        <Card>
          <div className="flex items-start justify-between mb-4">
            <div>
              <h2 className="text-xl font-bold text-white">{dayWorkout.title}</h2>
              <div className="flex items-center gap-3 text-xs text-gray-400 mt-1.5">
                <span className="flex items-center gap-1"><Clock className="w-3.5 h-3.5" /> {dayWorkout.duration_min} min</span>
                <span className="flex items-center gap-1"><Flame className="w-3.5 h-3.5" /> {dayWorkout.calories} cal</span>
                <Badge color={dayWorkout.difficulty === 'Hard' ? 'red' : dayWorkout.difficulty === 'Easy' ? 'cyan' : 'yellow'}>{dayWorkout.difficulty}</Badge>
              </div>
            </div>
            <button onClick={() => setWorkoutMode(dayWorkout)}
              className="bg-gradient-to-r from-emerald-400 to-cyan-500 text-[#08080c] font-bold px-5 py-2.5 rounded-xl hover:opacity-90 transition-all flex items-center gap-2 text-sm">
              <Play className="w-4 h-4 fill-current" /> Start
            </button>
          </div>

          <div className="space-y-2">
            {dayWorkout.exercises.map((ex, i) => (
              <div key={i} className="flex items-center gap-3 p-3 bg-white/[0.03] rounded-xl">
                <div className="w-7 h-7 rounded-lg bg-emerald-400/10 flex items-center justify-center text-emerald-400 text-xs font-bold shrink-0">{i + 1}</div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-white truncate">{ex.name}</p>
                  <p className="text-xs text-gray-500">{ex.sets} sets × {ex.reps} reps · {ex.weight_kg > 0 ? `${ex.weight_kg}kg` : 'Bodyweight'} · {ex.rest_sec}s rest</p>
                </div>
              </div>
            ))}
          </div>
        </Card>
      ) : (
        <Card className="text-center py-12">
          <p className="text-4xl mb-3">😴</p>
          <p className="text-sm text-gray-400">Rest day — no workout scheduled</p>
          <p className="text-xs text-gray-600 mt-1">Use this time for light recovery, stretching, or a walk</p>
        </Card>
      )}

      {/* Weekly overview */}
      <Card>
        <h3 className="font-semibold text-white mb-4">This Week</h3>
        <div className="grid grid-cols-7 gap-2">
          {days.map(dow => {
            const w = workouts.find(w => w.day_of_week === dow);
            return (
              <div key={dow} className="text-center">
                <p className="text-[10px] text-gray-500 mb-1">{getDayShort(dow)}</p>
                <div className={cn('aspect-square rounded-xl flex items-center justify-center text-lg',
                  w ? w.workout_type === 'Recovery' ? 'bg-blue-500/10' : 'bg-emerald-500/10' : 'bg-white/[0.02]')}>
                  {w ? w.workout_type === 'Recovery' ? '🧘' : w.workout_type === 'Cardio' ? '🏃' : '🏋️' : '😴'}
                </div>
              </div>
            );
          })}
        </div>
      </Card>
    </div>
  );
}

function WorkoutMode({ workout, onExit, onComplete }: {
  workout: Workout;
  onExit: () => void;
  onComplete: (exercises: Exercise[], durationMin: number) => void;
}) {
  const [exerciseIdx, setExerciseIdx] = useState(0);
  const [currentSet, setCurrentSet] = useState(1);
  const [paused, setPaused] = useState(false);
  const [restTimer, setRestTimer] = useState(0);
  const [elapsed, setElapsed] = useState(0);
  const [completedExercises, setCompletedExercises] = useState<Exercise[]>([]);
  const timerRef = useRef<number | null>(null);

  const exercise = workout.exercises[exerciseIdx];
  const isLastExercise = exerciseIdx === workout.exercises.length - 1;
  const isLastSet = currentSet >= exercise.sets;

  useEffect(() => {
    if (paused) return;
    timerRef.current = window.setInterval(() => {
      setElapsed(e => e + 1);
      setRestTimer(r => (r > 0 ? r - 1 : 0));
    }, 1000);
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [paused]);

  function completeSet() {
    if (isLastSet) {
      setCompletedExercises([...completedExercises, exercise]);
      if (isLastExercise) {
        onComplete(completedExercises, Math.floor(elapsed / 60));
      } else {
        setExerciseIdx(exerciseIdx + 1);
        setCurrentSet(1);
        setRestTimer(exercise.rest_sec);
      }
    } else {
      setCurrentSet(currentSet + 1);
      setRestTimer(exercise.rest_sec);
    }
  }

  function skipExercise() {
    if (isLastExercise) {
      onComplete([...completedExercises, ...workout.exercises.slice(exerciseIdx)], Math.floor(elapsed / 60));
    } else {
      setExerciseIdx(exerciseIdx + 1);
      setCurrentSet(1);
      setRestTimer(0);
    }
  }

  const mins = Math.floor(elapsed / 60);
  const secs = elapsed % 60;
  const restMins = Math.floor(restTimer / 60);
  const restSecs = restTimer % 60;
  const progress = ((exerciseIdx + (currentSet - 1) / exercise.sets) / workout.exercises.length) * 100;

  return (
    <div className="fixed inset-0 z-[60] bg-[#08080c] flex flex-col">
      {/* Header */}
      <div className="flex items-center justify-between px-5 py-4 border-b border-white/[0.06]">
        <button onClick={onExit} className="text-gray-400 hover:text-white"><X className="w-6 h-6" /></button>
        <div className="text-center">
          <p className="text-sm font-bold text-white">{workout.title}</p>
          <p className="text-xs text-gray-500">{String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}</p>
        </div>
        <button onClick={() => setPaused(!paused)} className="text-gray-400 hover:text-white">
          {paused ? <Play className="w-6 h-6" /> : <Pause className="w-6 h-6" />}
        </button>
      </div>

      {/* Progress bar */}
      <div className="h-1 bg-white/[0.06]">
        <div className="h-full bg-gradient-to-r from-emerald-400 to-cyan-500 transition-all duration-500" style={{ width: `${progress}%` }} />
      </div>

      {/* Exercise display */}
      <div className="flex-1 flex flex-col items-center justify-center px-6 max-w-md mx-auto w-full">
        <p className="text-xs text-gray-500 mb-2">Exercise {exerciseIdx + 1} of {workout.exercises.length}</p>
        <h2 className="text-3xl font-bold text-white text-center mb-8">{exercise.name}</h2>

        <div className="w-full bg-white/[0.03] border border-white/[0.06] rounded-3xl p-6 mb-6">
          <div className="grid grid-cols-3 gap-4 text-center">
            <div>
              <p className="text-xs text-gray-500 mb-1">Set</p>
              <p className="text-2xl font-bold text-white">{currentSet}<span className="text-sm text-gray-500">/{exercise.sets}</span></p>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-1">Reps</p>
              <p className="text-2xl font-bold text-white">{exercise.reps}</p>
            </div>
            <div>
              <p className="text-xs text-gray-500 mb-1">Weight</p>
              <p className="text-2xl font-bold text-white">{exercise.weight_kg}<span className="text-sm text-gray-500">kg</span></p>
            </div>
          </div>
        </div>

        {/* Rest timer */}
        {restTimer > 0 && (
          <div className="mb-6 text-center">
            <p className="text-xs text-gray-500 mb-1">Rest Timer</p>
            <p className="text-4xl font-bold text-cyan-400 tabular-nums">{String(restMins).padStart(2, '0')}:{String(restSecs).padStart(2, '0')}</p>
          </div>
        )}

        {/* Actions */}
        <div className="w-full space-y-3">
          <button onClick={completeSet}
            className="w-full bg-gradient-to-r from-emerald-400 to-cyan-500 text-[#08080c] font-bold py-4 rounded-2xl hover:opacity-90 transition-all flex items-center justify-center gap-2 text-base">
            <Check className="w-5 h-5" /> Complete Set
          </button>
          <div className="flex gap-3">
            <button onClick={skipExercise}
              className="flex-1 bg-white/[0.04] border border-white/[0.06] text-gray-400 font-medium py-3 rounded-2xl hover:bg-white/[0.08] transition-all flex items-center justify-center gap-2 text-sm">
              <SkipForward className="w-4 h-4" /> Skip
            </button>
            <button onClick={() => setPaused(!paused)}
              className="flex-1 bg-white/[0.04] border border-white/[0.06] text-gray-400 font-medium py-3 rounded-2xl hover:bg-white/[0.08] transition-all flex items-center justify-center gap-2 text-sm">
              {paused ? <><Play className="w-4 h-4" /> Resume</> : <><Pause className="w-4 h-4" /> Pause</>}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function CelebrationScreen({ data, onDone }: { data: { xp: number; statChanges: Record<string, number>; streak: number }; onDone: () => void }) {
  return (
    <div className="fixed inset-0 z-[60] bg-[#08080c] flex flex-col items-center justify-center px-6">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500/20 rounded-full blur-[120px] animate-pulse" />
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-cyan-500/20 rounded-full blur-[120px] animate-pulse" />
      </div>
      <div className="relative text-center max-w-sm w-full">
        <div className="text-6xl mb-4 animate-bounce">🎉</div>
        <h1 className="text-3xl font-bold text-white mb-2">Workout Complete!</h1>
        <p className="text-gray-400 mb-8">You crushed it. Here's what you earned:</p>

        <div className="space-y-3 mb-8">
          <div className="bg-yellow-400/10 border border-yellow-400/20 rounded-2xl p-4 flex items-center justify-between">
            <span className="text-sm text-gray-300">XP Earned</span>
            <span className="text-2xl font-bold text-yellow-400">+{data.xp}</span>
          </div>
          {Object.entries(data.statChanges).map(([stat, val]) => (
            <div key={stat} className="bg-white/[0.04] border border-white/[0.06] rounded-2xl p-4 flex items-center justify-between">
              <span className="text-sm text-gray-300">{stat}</span>
              <span className="text-lg font-bold text-emerald-400">+{val}</span>
            </div>
          ))}
          <div className="bg-orange-400/10 border border-orange-400/20 rounded-2xl p-4 flex items-center justify-between">
            <span className="text-sm text-gray-300">Streak</span>
            <span className="text-lg font-bold text-orange-400 flex items-center gap-1.5"><Flame className="w-5 h-5" /> {data.streak} days</span>
          </div>
        </div>

        <button onClick={onDone}
          className="w-full bg-gradient-to-r from-emerald-400 to-cyan-500 text-[#08080c] font-bold py-3.5 rounded-2xl hover:opacity-90 transition-all">
          Continue
        </button>
      </div>
    </div>
  );
}
