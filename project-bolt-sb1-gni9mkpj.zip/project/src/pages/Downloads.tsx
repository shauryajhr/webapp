import { Download, FileText, FileCode, FileCheck } from 'lucide-react';

const files = [
  {
    name: 'README.md',
    href: '/downloads/README.md',
    icon: FileText,
    description: 'GitHub readme: features, tech stack, setup steps, project structure.',
    filename: 'README.md',
  },
  {
    name: 'AUDIT.md',
    href: '/downloads/AUDIT.md',
    icon: FileCheck,
    description: 'Project audit: architecture, security review, findings, code quality.',
    filename: 'AUDIT.md',
  },
  {
    name: 'portfolio-index.html',
    href: '/downloads/portfolio-index.html',
    icon: FileCode,
    description: 'Standalone portfolio page. Rename to index.html when uploading.',
    filename: 'index.html',
  },
];

export default function Downloads() {
  return (
    <div className="min-h-screen bg-[#08080c] text-white flex items-start justify-center px-4 py-16">
      <div className="w-full max-w-xl">
        <h1 className="text-2xl font-bold tracking-tight mb-2">Download project files</h1>
        <p className="text-gray-400 text-sm mb-8 leading-relaxed">
          Click a file to download it. Upload all three to your GitHub repo (the portfolio file
          becomes <span className="text-gray-200">index.html</span> in the repo).
        </p>
        <div className="flex flex-col gap-3">
          {files.map((f) => (
            <a
              key={f.name}
              href={f.href}
              download={f.filename}
              className="group flex items-center gap-4 rounded-2xl border border-white/10 bg-white/[0.03] p-4 transition-all hover:border-emerald-400/50 hover:bg-white/[0.06]"
            >
              <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-emerald-400/10">
                <f.icon className="h-5 w-5 text-emerald-400" />
              </div>
              <div className="min-w-0 flex-1">
                <div className="text-sm font-semibold">{f.name}</div>
                <div className="text-xs text-gray-400 mt-0.5 leading-relaxed">{f.description}</div>
              </div>
              <Download className="h-5 w-5 shrink-0 text-gray-500 transition-colors group-hover:text-emerald-400" />
            </a>
          ))}
        </div>
      </div>
    </div>
  );
}
