import { useEffect, useState } from 'react';
import { TrendingUp, TrendingDown, Weight, Activity, Moon, Droplet, Footprints, Brain, Monitor, Flame } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { Card, Badge, ProgressBar } from '@/components/ui/Card';
import LineChart from '@/components/charts/LineChart';
import BarChart from '@/components/charts/BarChart';
import Heatmap from '@/components/charts/Heatmap';
import { cn, calculateConsistencyScore, formatNumber, dateStr } from '@/lib/utils';
import type { DailyLog, BodyMetric, WorkoutLog } from '@/types';

const METRICS = [
  { key: 'weight_kg', label: 'Weight', unit: 'kg', icon: Weight, color: '#f97316' },
  { key: 'steps', label: 'Steps', unit: '', icon: Footprints, color: '#34d399' },
  { key: 'sleep_hours', label: 'Sleep', unit: 'h', icon: Moon, color: '#3b82f6' },
  { key: 'water_liters', label: 'Water', unit: 'L', icon: Droplet, color: '#06b6d4' },
  { key: 'calories_eaten', label: 'Calories', unit: '', icon: Flame, color: '#ef4444' },
  { key: 'protein_g', label: 'Protein', unit: 'g', icon: Activity, color: '#8b5cf6' },
  { key: 'study_hours', label: 'Study', unit: 'h', icon: Brain, color: '#eab308' },
  { key: 'screen_time_hours', label: 'Screen Time', unit: 'h', icon: Monitor, color: '#6b7280' },
] as const;

type MetricKey = typeof METRICS[number]['key'];

export default function Growth() {
  const { profile } = useAuth();
  const [logs, setLogs] = useState<DailyLog[]>([]);
  const [bodyMetrics, setBodyMetrics] = useState<BodyMetric[]>([]);
  const [workoutLogs, setWorkoutLogs] = useState<WorkoutLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [activeMetric, setActiveMetric] = useState<MetricKey>('weight_kg');
  const [showNutrition, setShowNutrition] = useState(false);
  const [nutritionForm, setNutritionForm] = useState({ calories: '', protein: '', carbs: '', fats: '', water: '' });

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const [lRes, bRes, wRes] = await Promise.all([
        supabase.from('daily_logs').select('*').eq('user_id', profile.id).order('date', { ascending: true }).limit(90),
        supabase.from('body_metrics').select('*').eq('user_id', profile.id).order('date', { ascending: true }),
        supabase.from('workout_logs').select('*').eq('user_id', profile.id).order('date', { ascending: true }),
      ]);
      setLogs(lRes.data as DailyLog[] || []);
      setBodyMetrics(bRes.data as BodyMetric[] || []);
      setWorkoutLogs(wRes.data as WorkoutLog[] || []);
      setLoading(false);
    })();
  }, [profile]);

  async function logNutrition() {
    if (!profile) return;
    const today = dateStr(0);
    const existing = logs.find(l => l.date === today);
    const updates = {
      calories_eaten: (existing?.calories_eaten || 0) + (parseInt(nutritionForm.calories) || 0),
      protein_g: (existing?.protein_g || 0) + (parseInt(nutritionForm.protein) || 0),
      carbs_g: (existing?.carbs_g || 0) + (parseInt(nutritionForm.carbs) || 0),
      fats_g: (existing?.fats_g || 0) + (parseInt(nutritionForm.fats) || 0),
      water_liters: +((existing?.water_liters || 0) + (parseFloat(nutritionForm.water) || 0)).toFixed(2),
    };
    if (existing) {
      await supabase.from('daily_logs').update(updates).eq('id', existing.id);
    } else {
      await supabase.from('daily_logs').insert({ user_id: profile.id, date: today, ...updates });
    }
    setShowNutrition(false);
    setNutritionForm({ calories: '', protein: '', carbs: '', fats: '', water: '' });
    window.location.reload();
  }

  if (loading) return <div className="space-y-4 animate-pulse"><div className="h-10 w-60 bg-white/[0.04] rounded-xl" /><div className="h-80 bg-white/[0.04] rounded-2xl" /></div>;

  const last30 = logs.slice(-30);
  const last7 = logs.slice(-7);
  const prev7 = logs.slice(-14, -7);
  const consistencyScore = calculateConsistencyScore(last7);
  const prevConsistency = calculateConsistencyScore(prev7);
  const consistencyChange = consistencyScore - prevConsistency;

  const activeMetricInfo = METRICS.find(m => m.key === activeMetric)!;
  const isWeightMetric = activeMetric === 'weight_kg';
  const chartData = isWeightMetric
    ? bodyMetrics.map(b => ({ label: new Date(b.date).toLocaleDateString('en', { month: 'short', day: 'numeric' }), value: b.weight_kg || 0 }))
    : last30.map(l => ({ label: new Date(l.date).toLocaleDateString('en', { month: 'short', day: 'numeric' }), value: (l[activeMetric as keyof DailyLog] as number) || 0 }));

  // Week comparison data
  const weekData = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'].map((label, i) => {
    const dayIdx = i + 1;
    const thisWeek = last7.find(l => new Date(l.date).getDay() === dayIdx);
    const lastWeek = prev7.find(l => new Date(l.date).getDay() === dayIdx);
    return {
      label,
      value: isWeightMetric ? (bodyMetrics[bodyMetrics.length - 1]?.weight_kg || 0) : ((thisWeek?.[activeMetric as keyof DailyLog] as number) || 0),
      value2: isWeightMetric ? (bodyMetrics[0]?.weight_kg || 0) : ((lastWeek?.[activeMetric as keyof DailyLog] as number) || 0),
    };
  });

  // Heatmap data
  const heatmapData = logs.map(l => ({
    date: l.date,
    value: calculateConsistencyScore([l]),
  }));

  // Body metrics transformation
  const firstWeight = bodyMetrics[0]?.weight_kg || 0;
  const currentWeight = bodyMetrics[bodyMetrics.length - 1]?.weight_kg || 0;
  const weightChange = +(currentWeight - firstWeight).toFixed(1);
  const firstPushups = bodyMetrics[0]?.pushups_max || 0;
  const currentPushups = bodyMetrics[bodyMetrics.length - 1]?.pushups_max || 0;

  const streaks = [
    { label: 'Workout', value: last7.filter(l => l.workout_completed).length, icon: '🔥', max: 7 },
    { label: 'Study', value: last7.filter(l => l.study_hours >= 1).length, icon: '📚', max: 7 },
    { label: 'Hydration', value: last7.filter(l => l.water_liters >= 2).length, icon: '💧', max: 7 },
    { label: 'Sleep', value: last7.filter(l => l.sleep_hours >= 7).length, icon: '😴', max: 7 },
    { label: 'Meditation', value: last7.filter(l => l.meditation_minutes > 0).length, icon: '🧘', max: 7 },
  ];

  return (
    <div className="space-y-5 max-w-4xl mx-auto">
      <div>
        <h1 className="text-2xl font-bold text-white">Growth Tracker</h1>
        <p className="text-sm text-gray-400 mt-1">Your progress over time — body, mind, and consistency</p>
      </div>

      {/* Consistency Score */}
      <Card className="bg-gradient-to-br from-emerald-400/5 to-transparent border-emerald-400/10">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="font-semibold text-white">Consistency Score</h3>
            <p className="text-xs text-gray-500 mt-0.5">Last 7 days</p>
          </div>
          <div className="text-right">
            <p className="text-4xl font-bold text-emerald-400">{consistencyScore}<span className="text-lg text-gray-500">/100</span></p>
            {consistencyChange !== 0 && (
              <p className={cn('text-xs flex items-center justify-end gap-1', consistencyChange > 0 ? 'text-emerald-400' : 'text-red-400')}>
                {consistencyChange > 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                {Math.abs(consistencyChange)} pts
              </p>
            )}
          </div>
        </div>
        <ProgressBar value={consistencyScore} max={100} color="from-emerald-400 to-cyan-500" />
        <div className="grid grid-cols-5 gap-2 mt-4">
          {streaks.map(s => (
            <div key={s.label} className="text-center">
              <div className="flex items-center justify-center gap-1 mb-1">
                <span className="text-sm">{s.icon}</span>
                <span className="text-sm font-bold text-white">{s.value}</span>
                <span className="text-[10px] text-gray-500">/{s.max}</span>
              </div>
              <p className="text-[10px] text-gray-500">{s.label}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Consistency Calendar */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-white">Consistency Calendar</h3>
          <Badge color="emerald">Last 13 weeks</Badge>
        </div>
        <Heatmap cells={heatmapData} weeks={13} />
        <div className="flex items-center gap-2 mt-3 text-xs text-gray-500">
          <span>Less</span>
          <div className="w-3 h-3 rounded-sm bg-white/[0.04]" />
          <div className="w-3 h-3 rounded-sm bg-emerald-400/20" />
          <div className="w-3 h-3 rounded-sm bg-emerald-400/40" />
          <div className="w-3 h-3 rounded-sm bg-emerald-400/70" />
          <div className="w-3 h-3 rounded-sm bg-emerald-400" />
          <span>More</span>
        </div>
      </Card>

      {/* Metric selector + chart */}
      <Card>
        <div className="flex items-center gap-2 overflow-x-auto pb-1 mb-4">
          {METRICS.map(m => {
            const Icon = m.icon;
            return (
              <button key={m.key} onClick={() => setActiveMetric(m.key)}
                className={cn('flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-medium transition-all whitespace-nowrap',
                  activeMetric === m.key ? 'bg-white/[0.08] text-white border border-white/[0.12]' : 'bg-white/[0.03] text-gray-400 border border-transparent hover:bg-white/[0.06]')}>
                <Icon className="w-3.5 h-3.5" style={{ color: m.color }} />
                {m.label}
              </button>
            );
          })}
        </div>
        <LineChart data={chartData} color={activeMetricInfo.color} height={200} formatValue={v => `${Math.round(v * 10) / 10}${activeMetricInfo.unit}`} />
      </Card>

      {/* Week comparison */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-white">This Week vs Last Week</h3>
          <div className="flex items-center gap-3 text-xs">
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm" style={{ backgroundColor: activeMetricInfo.color }} /><span className="text-gray-400">This week</span></div>
            <div className="flex items-center gap-1.5"><div className="w-3 h-3 rounded-sm bg-white/20" /><span className="text-gray-400">Last week</span></div>
          </div>
        </div>
        <BarChart data={weekData} height={180} color={activeMetricInfo.color} color2="rgba(255,255,255,0.15)" formatValue={v => `${Math.round(v)}${activeMetricInfo.unit}`} />
      </Card>

      {/* 90-Day Transformation */}
      <Card>
        <h3 className="font-semibold text-white mb-4">90-Day Transformation</h3>
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <TransformCard label="Weight" from={`${firstWeight}kg`} to={`${currentWeight}kg`} change={`${weightChange > 0 ? '+' : ''}${weightChange}kg`} positive={weightChange <= 0} icon="⚖️" />
          <TransformCard label="Push-ups" from={`${firstPushups}`} to={`${currentPushups}`} change={`+${currentPushups - firstPushups}`} positive={true} icon="💪" />
          <TransformCard label="Consistency" from={`${prevConsistency}%`} to={`${consistencyScore}%`} change={`${consistencyChange > 0 ? '+' : ''}${consistencyChange}%`} positive={consistencyChange >= 0} icon="🎯" />
          <TransformCard label="Workouts" from={`${workoutLogs.length - last7.filter(l => l.workout_completed).length}`} to={`${workoutLogs.length}`} change={`+${last7.filter(l => l.workout_completed).length}`} positive={true} icon="🏋️" />
        </div>
      </Card>

      {/* Nutrition */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-white">Today's Nutrition</h3>
          <button onClick={() => setShowNutrition(!showNutrition)} className="text-xs text-emerald-400 hover:text-emerald-300 font-medium">
            {showNutrition ? 'Close' : 'Log Food'}
          </button>
        </div>
        {(() => {
          const today = logs.find(l => l.date === dateStr(0));
          const targets = { calories: 2200, protein: 140, carbs: 280, fats: 70, water: 2.5 };
          return (
            <>
              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                <NutritionStat label="Calories" value={today?.calories_eaten || 0} target={targets.calories} unit="" color="text-orange-400" />
                <NutritionStat label="Protein" value={today?.protein_g || 0} target={targets.protein} unit="g" color="text-violet-400" />
                <NutritionStat label="Carbs" value={today?.carbs_g || 0} target={targets.carbs} unit="g" color="text-blue-400" />
                <NutritionStat label="Fats" value={today?.fats_g || 0} target={targets.fats} unit="g" color="text-yellow-400" />
                <NutritionStat label="Water" value={today?.water_liters || 0} target={targets.water} unit="L" color="text-cyan-400" />
              </div>
              {showNutrition && (
                <div className="mt-4 pt-4 border-t border-white/[0.06] space-y-3">
                  <p className="text-xs text-gray-400">Quick Log — adds to today's totals</p>
                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                    <input type="number" value={nutritionForm.calories} onChange={e => setNutritionForm({ ...nutritionForm, calories: e.target.value })} placeholder="Calories"
                      className="bg-white/[0.04] border border-white/[0.06] rounded-xl px-3 py-2 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
                    <input type="number" value={nutritionForm.protein} onChange={e => setNutritionForm({ ...nutritionForm, protein: e.target.value })} placeholder="Protein (g)"
                      className="bg-white/[0.04] border border-white/[0.06] rounded-xl px-3 py-2 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
                    <input type="number" value={nutritionForm.water} onChange={e => setNutritionForm({ ...nutritionForm, water: e.target.value })} placeholder="Water (L)"
                      className="bg-white/[0.04] border border-white/[0.06] rounded-xl px-3 py-2 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
                  </div>
                  <button onClick={logNutrition}
                    className="w-full bg-gradient-to-r from-emerald-400 to-cyan-500 text-[#08080c] font-bold py-2.5 rounded-xl hover:opacity-90 transition-all text-sm">
                    Add to Today
                  </button>
                </div>
              )}
            </>
          );
        })()}
      </Card>
    </div>
  );
}

function TransformCard({ label, from, to, change, positive, icon }: { label: string; from: string; to: string; change: string; positive: boolean; icon: string }) {
  return (
    <div className="bg-white/[0.03] rounded-xl p-3 text-center">
      <div className="text-xl mb-1">{icon}</div>
      <p className="text-[10px] text-gray-500 mb-1">{label}</p>
      <p className="text-sm text-gray-400">{from}</p>
      <p className="text-xs text-gray-600">→</p>
      <p className="text-sm font-bold text-white">{to}</p>
      <p className={cn('text-xs font-medium mt-1', positive ? 'text-emerald-400' : 'text-red-400')}>{change}</p>
    </div>
  );
}

function NutritionStat({ label, value, target, unit, color }: { label: string; value: number; target: number; unit: string; color: string }) {
  return (
    <div className="bg-white/[0.03] rounded-xl p-3">
      <p className="text-[10px] text-gray-500 mb-1">{label}</p>
      <p className={cn('text-lg font-bold', color)}>{Math.round(value * 10) / 10}<span className="text-xs text-gray-500"> / {target}{unit}</span></p>
      <ProgressBar value={value} max={target} className="mt-2" />
    </div>
  );
}
