import { useEffect, useState } from 'react';
import { Target, Plus, X, Trash2, CheckCircle2, Clock, Sparkles, TrendingUp, LogOut, Download, Shield, Bell, Palette } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { Card, ProgressRing, ProgressBar, Badge } from '@/components/ui/Card';
import { cn, levelFromXp, levelTitle, calculateConsistencyScore, getStreak } from '@/lib/utils';
import { calculateProjectedWeight, calculateProjectedConsistency } from '@/lib/gamification';
import type { Goal, Badge as BadgeType, DailyLog, WorkoutLog, Profile as ProfileType } from '@/types';

export default function ProfilePage() {
  const { profile, signOut, updateProfile } = useAuth();
  const [goals, setGoals] = useState<Goal[]>([]);
  const [badges, setBadges] = useState<BadgeType[]>([]);
  const [logs, setLogs] = useState<DailyLog[]>([]);
  const [workoutLogs, setWorkoutLogs] = useState<WorkoutLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<'character' | 'goals' | 'future' | 'settings'>('character');
  const [showGoalModal, setShowGoalModal] = useState(false);
  const [goalForm, setGoalForm] = useState({ type: 'weight', title: '', target: '', unit: 'kg', deadline: '' });
  const [futureDays, setFutureDays] = useState(90);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const [gRes, bRes, lRes, wRes] = await Promise.all([
        supabase.from('goals').select('*').eq('user_id', profile.id).order('created_at', { ascending: false }),
        supabase.from('badges').select('*').eq('user_id', profile.id).order('earned_at', { ascending: false }),
        supabase.from('daily_logs').select('*').eq('user_id', profile.id).order('date', { ascending: true }).limit(30),
        supabase.from('workout_logs').select('*').eq('user_id', profile.id),
      ]);
      setGoals(gRes.data as Goal[] || []);
      setBadges(bRes.data as BadgeType[] || []);
      setLogs(lRes.data as DailyLog[] || []);
      setWorkoutLogs(wRes.data as WorkoutLog[] || []);
      setLoading(false);
    })();
  }, [profile]);

  async function createGoal() {
    if (!profile || !goalForm.title.trim() || !goalForm.target) return;
    const { data } = await supabase.from('goals').insert({
      user_id: profile.id, type: goalForm.type, title: goalForm.title,
      target_value: parseFloat(goalForm.target), current_value: 0, unit: goalForm.unit,
      deadline: goalForm.deadline || null, status: 'active',
    }).select('*').maybeSingle();
    if (data) setGoals([data as Goal, ...goals]);
    setShowGoalModal(false);
    setGoalForm({ type: 'weight', title: '', target: '', unit: 'kg', deadline: '' });
  }

  async function updateGoalProgress(goal: Goal, value: string) {
    const newVal = parseFloat(value) || 0;
    const status = newVal >= goal.target_value ? 'completed' : 'active';
    const { data } = await supabase.from('goals').update({ current_value: newVal, status }).eq('id', goal.id).select('*').maybeSingle();
    if (data) setGoals(goals.map(g => g.id === goal.id ? data as Goal : g));
  }

  async function deleteGoal(id: string) {
    await supabase.from('goals').delete().eq('id', id);
    setGoals(goals.filter(g => g.id !== id));
  }

  async function handleDeleteAccount() {
    if (!profile) return;
    if (!confirm('This will permanently delete all your data. This cannot be undone. Are you sure?')) return;
    await Promise.all([
      supabase.from('daily_logs').delete().eq('user_id', profile.id),
      supabase.from('workout_logs').delete().eq('user_id', profile.id),
      supabase.from('goals').delete().eq('user_id', profile.id),
      supabase.from('habits').delete().eq('user_id', profile.id),
      supabase.from('badges').delete().eq('user_id', profile.id),
      supabase.from('body_metrics').delete().eq('user_id', profile.id),
      supabase.from('schedule_items').delete().eq('user_id', profile.id),
      supabase.from('quests').delete().eq('user_id', profile.id),
      supabase.from('ai_insights').delete().eq('user_id', profile.id),
      supabase.from('workouts').delete().eq('user_id', profile.id),
      supabase.from('profiles').delete().eq('id', profile.id),
    ]);
    await signOut();
  }

  function handleExportData() {
    if (!profile) return;
    const data = { profile, goals, badges, logs: logs.slice(-30), workoutLogs };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `levelup-export-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (loading || !profile) return <div className="space-y-4 animate-pulse"><div className="h-10 w-60 bg-white/[0.04] rounded-xl" /></div>;

  const levelInfo = levelFromXp(profile.xp);
  const levelName = levelTitle(profile.level);
  const streak = getStreak(logs.map(l => ({ date: l.date, workout_completed: l.workout_completed })));
  const consistencyScore = calculateConsistencyScore(logs.slice(-7));

  const stats = [
    { icon: '💪', label: 'Strength', value: profile.strength, color: '#f97316' },
    { icon: '❤️', label: 'Health', value: profile.health, color: '#ef4444' },
    { icon: '🧠', label: 'Discipline', value: profile.discipline, color: '#8b5cf6' },
    { icon: '⚡', label: 'Energy', value: profile.energy, color: '#eab308' },
    { icon: '🎯', label: 'Consistency', value: profile.consistency, color: '#34d399' },
  ];

  const activeGoals = goals.filter(g => g.status === 'active');
  const completedGoals = goals.filter(g => g.status === 'completed');

  // Future Self projections
  const projectedWeight = calculateProjectedWeight(profile.weight_kg || 80, consistencyScore, futureDays);
  const projectedConsistency = calculateProjectedConsistency(consistencyScore, futureDays);
  const projectedLevel = levelFromXp(profile.xp + workoutLogs.length * 100 * (futureDays / 7) * (projectedConsistency / 100)).level;

  return (
    <div className="space-y-5 max-w-3xl mx-auto">
      {/* Character header */}
      <Card className="bg-gradient-to-br from-emerald-400/5 via-cyan-500/5 to-transparent border-emerald-400/10">
        <div className="flex items-center gap-5 flex-wrap">
          <div className="relative">
            <ProgressRing progress={levelInfo.progress} size={90} strokeWidth={6} color="#34d399">
              <div className="text-center">
                <p className="text-2xl font-bold text-white">{profile.level}</p>
                <p className="text-[9px] text-gray-500">Level</p>
              </div>
            </ProgressRing>
          </div>
          <div className="flex-1 min-w-[180px]">
            <h1 className="text-2xl font-bold text-white">{profile.name}</h1>
            <p className="text-sm text-emerald-400 font-medium">{levelName}</p>
            <div className="flex items-center gap-4 mt-2 text-xs text-gray-400">
              <span>🔥 {streak} day streak</span>
              <span>🎯 {consistencyScore}/100</span>
              <span>🏆 {badges.length} badges</span>
            </div>
          </div>
        </div>
      </Card>

      {/* Tab selector */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {([
          { id: 'character', label: 'Character' },
          { id: 'goals', label: 'Goals' },
          { id: 'future', label: 'Future Self' },
          { id: 'settings', label: 'Settings' },
        ] as const).map(t => (
          <button key={t.id} onClick={() => setTab(t.id)}
            className={cn('px-4 py-2 rounded-xl text-sm font-medium transition-all whitespace-nowrap',
              tab === t.id ? 'bg-white/[0.08] text-white border border-white/[0.12]' : 'bg-white/[0.03] text-gray-400 border border-transparent hover:bg-white/[0.06]')}>
            {t.label}
          </button>
        ))}
      </div>

      {/* Character tab */}
      {tab === 'character' && (
        <>
          <Card>
            <h3 className="font-semibold text-white mb-4">Character Stats</h3>
            <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
              {stats.map(stat => (
                <div key={stat.label} className="flex flex-col items-center">
                  <ProgressRing progress={stat.value} size={72} strokeWidth={6} color={stat.color}>
                    <p className="text-lg font-bold text-white">{stat.value}</p>
                  </ProgressRing>
                  <p className="text-xs text-gray-400 mt-2">{stat.icon} {stat.label}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-2">
              <h3 className="font-semibold text-white">XP Progress</h3>
              <Badge color="yellow">{profile.xp.toLocaleString()} XP</Badge>
            </div>
            <p className="text-xs text-gray-500 mb-2">Level {profile.level} — {levelName}</p>
            <ProgressBar value={levelInfo.xpIntoLevel} max={levelInfo.xpForNextLevel} color="from-yellow-400 to-orange-500" />
            <p className="text-xs text-gray-500 mt-2">{levelInfo.xpIntoLevel} / {levelInfo.xpForNextLevel} XP to Level {profile.level + 1}</p>
          </Card>

          <Card>
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-semibold text-white">Life Level Breakdown</h3>
              <span className="text-2xl font-bold text-emerald-400">{profile.life_level}<span className="text-sm text-gray-500">/100</span></span>
            </div>
            <div className="space-y-2.5">
              {[
                { label: 'Fitness (25%)', value: profile.strength * 0.25, max: 25 },
                { label: 'Health (20%)', value: profile.health * 0.20, max: 20 },
                { label: 'Discipline (20%)', value: profile.discipline * 0.20, max: 20 },
                { label: 'Energy (15%)', value: profile.energy * 0.15, max: 15 },
                { label: 'Consistency (10%)', value: profile.consistency * 0.10, max: 10 },
                { label: 'Overall Avg (10%)', value: (profile.strength + profile.health + profile.discipline + profile.energy + profile.consistency) / 5 * 0.10, max: 10 },
              ].map(item => (
                <div key={item.label}>
                  <div className="flex justify-between text-xs text-gray-400 mb-1">
                    <span>{item.label}</span>
                    <span>{item.value.toFixed(1)}/{item.max}</span>
                  </div>
                  <ProgressBar value={item.value} max={item.max} className="h-1.5" />
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <h3 className="font-semibold text-white mb-4">Achievements ({badges.length})</h3>
            <div className="grid grid-cols-3 sm:grid-cols-6 gap-3">
              {badges.map(badge => (
                <div key={badge.id} className="flex flex-col items-center text-center">
                  <div className="w-14 h-14 rounded-2xl bg-gradient-to-br from-yellow-400/15 to-orange-500/15 border border-yellow-400/10 flex items-center justify-center text-2xl mb-1.5">
                    {badge.icon}
                  </div>
                  <p className="text-[10px] text-gray-400 leading-tight">{badge.name}</p>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <h3 className="font-semibold text-white mb-4">Profile Info</h3>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-sm">
              <InfoItem label="Age" value={profile.age ? String(profile.age) : '—'} />
              <InfoItem label="Height" value={profile.height_cm ? `${profile.height_cm}cm` : '—'} />
              <InfoItem label="Weight" value={profile.weight_kg ? `${profile.weight_kg}kg` : '—'} />
              <InfoItem label="Goal" value={profile.fitness_goal || '—'} />
              <InfoItem label="Activity" value={profile.activity_level || '—'} />
              <InfoItem label="Experience" value={profile.experience_level || '—'} />
              <InfoItem label="Sleep Target" value={`${profile.sleep_target_hours}h`} />
              <InfoItem label="Daily Time" value={profile.daily_available_time || '—'} />
              <InfoItem label="Personal Goals" value={profile.personal_goals || '—'} />
            </div>
          </Card>
        </>
      )}

      {/* Goals tab */}
      {tab === 'goals' && (
        <>
          <div className="flex items-center justify-between">
            <h2 className="text-lg font-semibold text-white">Goals ({activeGoals.length} active)</h2>
            <button onClick={() => setShowGoalModal(true)}
              className="bg-gradient-to-r from-emerald-400 to-cyan-500 text-[#08080c] font-bold px-4 py-2.5 rounded-xl hover:opacity-90 transition-all flex items-center gap-2 text-sm">
              <Plus className="w-4 h-4" /> New Goal
            </button>
          </div>

          {activeGoals.length === 0 ? (
            <Card className="text-center py-10"><p className="text-sm text-gray-500">No active goals. Create one to start tracking!</p></Card>
          ) : (
            <div className="space-y-3">
              {activeGoals.map(goal => <GoalCard key={goal.id} goal={goal} onUpdate={updateGoalProgress} onDelete={deleteGoal} />)}
            </div>
          )}

          {completedGoals.length > 0 && (
            <>
              <h3 className="text-sm font-semibold text-gray-400 mt-6 mb-3">Completed</h3>
              <div className="space-y-3">
                {completedGoals.map(goal => <GoalCard key={goal.id} goal={goal} onUpdate={updateGoalProgress} onDelete={deleteGoal} />)}
              </div>
            </>
          )}
        </>
      )}

      {/* Future Self tab */}
      {tab === 'future' && (
        <>
          <Card className="bg-gradient-to-br from-violet-500/5 via-transparent to-cyan-500/5 border-violet-500/10">
            <div className="flex items-center gap-2 mb-4">
              <Sparkles className="w-5 h-5 text-violet-400" />
              <h3 className="font-semibold text-white">Future Self Projection</h3>
            </div>
            <p className="text-sm text-gray-400 mb-6">See what your progress could look like if you maintain your current consistency. These are estimates, not guarantees — your effort determines the outcome.</p>

            <div className="mb-6">
              <label className="block text-xs text-gray-400 mb-2">Projection timeframe: {futureDays} days</label>
              <input type="range" min="30" max="365" step="30" value={futureDays} onChange={e => setFutureDays(parseInt(e.target.value))}
                className="w-full accent-violet-400" />
              <div className="flex justify-between text-[10px] text-gray-600 mt-1">
                <span>30 days</span><span>90 days</span><span>180 days</span><span>365 days</span>
              </div>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <ProjectionCard icon="⚖️" label="Weight" current={`${profile.weight_kg || 0}kg`} projected={`${projectedWeight}kg`} positive={projectedWeight < (profile.weight_kg || 0)} />
              <ProjectionCard icon="🎯" label="Consistency" current={`${consistencyScore}%`} projected={`${projectedConsistency}%`} positive={projectedConsistency > consistencyScore} />
              <ProjectionCard icon="🏆" label="Level" current={`Lv ${profile.level}`} projected={`Lv ${projectedLevel}`} positive={projectedLevel > profile.level} />
              <ProjectionCard icon="🔥" label="Streak" current={`${streak} days`} projected={`${streak + Math.floor(futureDays * 0.7)} days`} positive={true} />
            </div>

            <div className="mt-6 p-4 bg-violet-500/5 border border-violet-500/10 rounded-xl">
              <p className="text-sm text-gray-300">
                If you maintain your current consistency for {futureDays} days, you could reach <span className="text-violet-400 font-bold">Level {projectedLevel}</span>,
                weigh approximately <span className="text-violet-400 font-bold">{projectedWeight}kg</span>,
                and achieve <span className="text-violet-400 font-bold">{projectedConsistency}%</span> consistency.
              </p>
              <p className="text-xs text-gray-500 mt-2">This is based on your current trajectory. Real results depend on your daily actions.</p>
            </div>
          </Card>
        </>
      )}

      {/* Settings tab */}
      {tab === 'settings' && (
        <>
          <Card>
            <div className="flex items-center gap-2 mb-4">
              <Bell className="w-5 h-5 text-emerald-400" />
              <h3 className="font-semibold text-white">Notifications</h3>
            </div>
            <div className="space-y-3">
              {['Workout reminders', 'Daily check-in', 'Goal progress alerts', 'Streak warnings'].map(label => (
                <div key={label} className="flex items-center justify-between p-3 bg-white/[0.03] rounded-xl">
                  <span className="text-sm text-white">{label}</span>
                  <div className="w-11 h-6 rounded-full bg-emerald-400/20 relative cursor-pointer">
                    <div className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-emerald-400" />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-2 mb-4">
              <Palette className="w-5 h-5 text-emerald-400" />
              <h3 className="font-semibold text-white">Appearance</h3>
            </div>
            <div className="flex items-center justify-between p-3 bg-white/[0.03] rounded-xl">
              <span className="text-sm text-white">Dark Mode</span>
              <div className="w-11 h-6 rounded-full bg-emerald-400/20 relative">
                <div className="absolute top-0.5 right-0.5 w-5 h-5 rounded-full bg-emerald-400" />
              </div>
            </div>
          </Card>

          <Card>
            <div className="flex items-center gap-2 mb-4">
              <Shield className="w-5 h-5 text-emerald-400" />
              <h3 className="font-semibold text-white">Data & Privacy</h3>
            </div>
            <div className="space-y-3">
              <button onClick={handleExportData} className="w-full text-left p-3 bg-white/[0.03] rounded-xl hover:bg-white/[0.06] transition-all flex items-center gap-3">
                <Download className="w-4 h-4 text-gray-400" />
                <div>
                  <p className="text-sm font-medium text-white">Export My Data</p>
                  <p className="text-xs text-gray-500">Download all your data as JSON</p>
                </div>
              </button>
              <button onClick={handleDeleteAccount} className="w-full text-left p-3 bg-red-500/5 border border-red-500/10 rounded-xl hover:bg-red-500/10 transition-all">
                <p className="text-sm font-medium text-red-400">Delete Account</p>
                <p className="text-xs text-gray-500 mt-0.5">Permanently delete all data. This cannot be undone.</p>
              </button>
              <button onClick={signOut} className="w-full text-left p-3 bg-white/[0.03] rounded-xl hover:bg-white/[0.06] transition-all flex items-center gap-3">
                <LogOut className="w-4 h-4 text-gray-400" />
                <p className="text-sm font-medium text-white">Sign Out</p>
              </button>
            </div>
          </Card>

          <p className="text-center text-xs text-gray-600 py-4">LevelUp — Don't just track your life. Level it up.</p>
        </>
      )}

      {/* Goal modal */}
      {showGoalModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setShowGoalModal(false)}>
          <div className="bg-[#13131c] border border-white/[0.08] rounded-3xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-semibold text-white text-lg">New Goal</h3>
              <button onClick={() => setShowGoalModal(false)} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 mb-1.5">Goal Title</label>
                <input value={goalForm.title} onChange={e => setGoalForm({ ...goalForm, title: e.target.value })} placeholder="e.g. Lose 5 KG"
                  className="w-full bg-white/[0.04] border border-white/[0.06] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-gray-400 mb-1.5">Target Value</label>
                  <input type="number" value={goalForm.target} onChange={e => setGoalForm({ ...goalForm, target: e.target.value })} placeholder="5"
                    className="w-full bg-white/[0.04] border border-white/[0.06] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1.5">Unit</label>
                  <input value={goalForm.unit} onChange={e => setGoalForm({ ...goalForm, unit: e.target.value })} placeholder="kg"
                    className="w-full bg-white/[0.04] border border-white/[0.06] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
                </div>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1.5">Deadline (optional)</label>
                <input type="date" value={goalForm.deadline} onChange={e => setGoalForm({ ...goalForm, deadline: e.target.value })}
                  className="w-full bg-white/[0.04] border border-white/[0.06] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-400/40" />
              </div>
              <button onClick={createGoal} disabled={!goalForm.title.trim() || !goalForm.target}
                className="w-full bg-gradient-to-r from-emerald-400 to-cyan-500 text-[#08080c] font-bold py-2.5 rounded-xl hover:opacity-90 transition-all disabled:opacity-50 text-sm">
                Create Goal
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function GoalCard({ goal, onUpdate, onDelete }: { goal: Goal; onUpdate: (goal: Goal, value: string) => void; onDelete: (id: string) => void }) {
  const [editing, setEditing] = useState(false);
  const [val, setVal] = useState(String(goal.current_value));
  const pct = Math.min(100, (goal.current_value / goal.target_value) * 100);
  const isComplete = goal.status === 'completed';

  return (
    <Card hover className={cn(isComplete && 'border-emerald-400/20 bg-emerald-400/5')}>
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="flex items-center gap-2">
          {isComplete ? <CheckCircle2 className="w-5 h-5 text-emerald-400" /> : <Target className="w-5 h-5 text-gray-400" />}
          <h4 className="font-medium text-white">{goal.title}</h4>
        </div>
        <button onClick={() => onDelete(goal.id)} className="text-gray-600 hover:text-red-400 p-1"><Trash2 className="w-4 h-4" /></button>
      </div>
      <div className="flex items-baseline gap-2 mb-3">
        <span className="text-2xl font-bold text-white">{goal.current_value}<span className="text-sm text-gray-500"> / {goal.target_value} {goal.unit}</span></span>
        <span className="ml-auto text-sm font-medium text-emerald-400">{pct.toFixed(0)}%</span>
      </div>
      <ProgressBar value={goal.current_value} max={goal.target_value} color={isComplete ? 'from-emerald-400 to-green-400' : 'from-emerald-400 to-cyan-500'} />
      <div className="flex items-center justify-between mt-3">
        {goal.deadline && <Badge color="gray"><Clock className="w-3 h-3 mr-1 inline" />{new Date(goal.deadline).toLocaleDateString('en', { month: 'short', day: 'numeric' })}</Badge>}
        {editing ? (
          <div className="flex items-center gap-2 ml-auto">
            <input type="number" value={val} onChange={e => setVal(e.target.value)} className="w-20 bg-white/[0.04] border border-white/[0.06] rounded-lg px-2 py-1 text-sm text-white focus:outline-none focus:border-emerald-400/40" />
            <button onClick={() => { onUpdate(goal, val); setEditing(false); }} className="text-xs text-emerald-400 hover:text-emerald-300 font-medium">Save</button>
          </div>
        ) : (
          <button onClick={() => { setVal(String(goal.current_value)); setEditing(true); }} className="text-xs text-emerald-400 hover:text-emerald-300 font-medium ml-auto">Update Progress</button>
        )}
      </div>
    </Card>
  );
}

function InfoItem({ label, value }: { label: string; value: string }) {
  return (
    <div className="bg-white/[0.03] rounded-xl p-3">
      <p className="text-[10px] text-gray-500 mb-0.5">{label}</p>
      <p className="text-sm text-white truncate">{value}</p>
    </div>
  );
}

function ProjectionCard({ icon, label, current, projected, positive }: { icon: string; label: string; current: string; projected: string; positive: boolean }) {
  return (
    <div className="bg-white/[0.03] rounded-xl p-3 text-center">
      <div className="text-xl mb-1">{icon}</div>
      <p className="text-[10px] text-gray-500 mb-1">{label}</p>
      <p className="text-sm text-gray-400">{current}</p>
      <p className="text-xs text-violet-400">↓</p>
      <p className="text-sm font-bold text-white">{projected}</p>
      <p className={cn('text-[10px] font-medium mt-0.5', positive ? 'text-emerald-400' : 'text-orange-400')}>{positive ? 'Improvement' : 'Projected'}</p>
    </div>
  );
}
