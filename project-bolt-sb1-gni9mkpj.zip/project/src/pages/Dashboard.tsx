import { useEffect, useState } from 'react';
import { Flame, Zap, Target, Trophy, CheckCircle2, Circle, Droplet, Footprints, BookOpen, Moon, Dumbbell, Sparkles, TrendingUp } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { Card, ProgressRing, ProgressBar, Badge } from '@/components/ui/Card';
import { cn, getGreeting, todayStr, getStreak, calculateConsistencyScore, levelFromXp, levelTitle, todayDayOfWeek, getDayShort } from '@/lib/utils';
import { generateCoachInsights, generateMotivationalMessage } from '@/lib/coach';
import type { DailyLog, Quest, Workout, Habit, Goal, Profile, WorkoutLog, Badge as BadgeType } from '@/types';

export default function Dashboard() {
  const { profile } = useAuth();
  const [dailyLog, setDailyLog] = useState<DailyLog | null>(null);
  const [quests, setQuests] = useState<Quest[]>([]);
  const [todayWorkout, setTodayWorkout] = useState<Workout | null>(null);
  const [habits, setHabits] = useState<Habit[]>([]);
  const [goals, setGoals] = useState<Goal[]>([]);
  const [recentLogs, setRecentLogs] = useState<DailyLog[]>([]);
  const [workoutLogs, setWorkoutLogs] = useState<WorkoutLog[]>([]);
  const [badges, setBadges] = useState<BadgeType[]>([]);
  const [loading, setLoading] = useState(true);
  const [checkInOpen, setCheckInOpen] = useState(false);

  useEffect(() => {
    if (!profile) return;
    (async () => {
      const today = todayStr();
      const dow = todayDayOfWeek();

      const [dlRes, qRes, wRes, hRes, gRes, wlRes, bRes] = await Promise.all([
        supabase.from('daily_logs').select('*').eq('user_id', profile.id).eq('date', today).maybeSingle(),
        supabase.from('quests').select('*').eq('user_id', profile.id).eq('date', today).order('created_at', { ascending: true }),
        supabase.from('workouts').select('*').eq('user_id', profile.id).eq('day_of_week', dow).maybeSingle(),
        supabase.from('habits').select('*').eq('user_id', profile.id).eq('active', true),
        supabase.from('goals').select('*').eq('user_id', profile.id).eq('status', 'active').order('created_at', { ascending: false }).limit(3),
        supabase.from('workout_logs').select('*').eq('user_id', profile.id).order('date', { ascending: false }).limit(30),
        supabase.from('badges').select('*').eq('user_id', profile.id).order('earned_at', { ascending: false }),
      ]);

      setDailyLog(dlRes.data as DailyLog | null);
      setQuests(qRes.data as Quest[] || []);
      setTodayWorkout(wRes.data as Workout | null);
      setHabits(hRes.data as Habit[] || []);
      setGoals(gRes.data as Goal[] || []);
      setWorkoutLogs(wlRes.data as WorkoutLog[] || []);
      setBadges(bRes.data as BadgeType[] || []);

      const { data: logsData } = await supabase.from('daily_logs').select('*').eq('user_id', profile.id).order('date', { ascending: true }).limit(30);
      setRecentLogs(logsData as DailyLog[] || []);
      setLoading(false);
    })();
  }, [profile]);

  async function toggleQuest(quest: Quest) {
    const completed = !quest.completed;
    const { data } = await supabase.from('quests').update({ completed }).eq('id', quest.id).select('*').maybeSingle();
    if (data) {
      setQuests(quests.map(q => q.id === quest.id ? data as Quest : q));
      if (completed && profile) {
        const newProfile = { ...profile, xp: profile.xp + quest.xp_reward };
        await supabase.from('profiles').update({ xp: newProfile.xp }).eq('id', profile.id);
      }
    }
  }

  async function logWater() {
    if (!profile) return;
    const today = todayStr();
    if (dailyLog) {
      const newVal = +(dailyLog.water_liters + 0.25).toFixed(2);
      const { data } = await supabase.from('daily_logs').update({ water_liters: newVal }).eq('id', dailyLog.id).select('*').maybeSingle();
      if (data) setDailyLog(data as DailyLog);
    } else {
      const { data } = await supabase.from('daily_logs').insert({ user_id: profile.id, date: today, water_liters: 0.25 }).select('*').maybeSingle();
      if (data) setDailyLog(data as DailyLog);
    }
  }

  async function saveCheckIn(energy: number, mood: number, stress: number, sleep: number) {
    if (!profile) return;
    const today = todayStr();
    if (dailyLog) {
      const { data } = await supabase.from('daily_logs').update({ energy_level: energy, mood, stress_level: stress, sleep_hours: sleep }).eq('id', dailyLog.id).select('*').maybeSingle();
      if (data) setDailyLog(data as DailyLog);
    } else {
      const { data } = await supabase.from('daily_logs').insert({ user_id: profile.id, date: today, energy_level: energy, mood, stress_level: stress, sleep_hours: sleep }).select('*').maybeSingle();
      if (data) setDailyLog(data as DailyLog);
    }
    setCheckInOpen(false);
  }

  if (loading || !profile) return <DashboardSkeleton />;

  const streak = getStreak(recentLogs.map(l => ({ date: l.date, workout_completed: l.workout_completed })));
  const consistencyScore = calculateConsistencyScore(recentLogs.slice(-7));
  const levelInfo = levelFromXp(profile.xp);
  const levelName = levelTitle(profile.level);

  const coachInsights = generateCoachInsights(recentLogs, workoutLogs, profile, goals);
  const motivationalMsg = generateMotivationalMessage(profile, streak, consistencyScore);

  // Daily mission progress
  const missionItems = [
    { label: 'Workout', done: dailyLog?.workout_completed || false, icon: Dumbbell },
    { label: '8K Steps', done: (dailyLog?.steps || 0) >= 8000, icon: Footprints },
    { label: '2L Water', done: (dailyLog?.water_liters || 0) >= 2, icon: Droplet },
    { label: '7h Sleep', done: (dailyLog?.sleep_hours || 0) >= 7, icon: Moon },
  ];
  const missionDone = missionItems.filter(m => m.done).length;
  const missionPct = (missionDone / missionItems.length) * 100;

  const completedQuests = quests.filter(q => q.completed).length;
  const totalQuestXp = quests.reduce((s, q) => s + q.xp_reward, 0);
  const earnedQuestXp = quests.filter(q => q.completed).reduce((s, q) => s + q.xp_reward, 0);

  const stats = [
    { icon: '💪', label: 'Strength', value: profile.strength, color: '#f97316' },
    { icon: '❤️', label: 'Health', value: profile.health, color: '#ef4444' },
    { icon: '🧠', label: 'Discipline', value: profile.discipline, color: '#8b5cf6' },
    { icon: '⚡', label: 'Energy', value: profile.energy, color: '#eab308' },
    { icon: '🎯', label: 'Consistency', value: profile.consistency, color: '#34d399' },
  ];

  const todayName = getDayShort(todayDayOfWeek());

  return (
    <div className="space-y-5 max-w-5xl mx-auto">
      {/* Greeting + Level */}
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-white">{getGreeting()}, {profile.name} 👋</h1>
          <p className="text-sm text-gray-400 mt-1 max-w-md">{motivationalMsg}</p>
        </div>
        <div className="flex items-center gap-3 bg-white/[0.03] border border-white/[0.06] rounded-2xl px-5 py-3">
          <div className="text-right">
            <p className="text-xs text-gray-500">Level</p>
            <p className="text-2xl font-bold text-white">{profile.level}</p>
          </div>
          <div className="w-px h-10 bg-white/10" />
          <div>
            <p className="text-xs text-emerald-400 font-medium">{levelName}</p>
            <p className="text-xs text-gray-500">{levelInfo.xpIntoLevel}/{levelInfo.xpForNextLevel} XP</p>
          </div>
        </div>
      </div>

      {/* Quick stats strip */}
      <div className="grid grid-cols-4 gap-3">
        <Card className="text-center !p-3">
          <Flame className="w-5 h-5 text-orange-400 mx-auto mb-1" />
          <p className="text-xl font-bold text-white">{streak}</p>
          <p className="text-[10px] text-gray-500">Day Streak</p>
        </Card>
        <Card className="text-center !p-3">
          <Zap className="w-5 h-5 text-yellow-400 mx-auto mb-1" />
          <p className="text-xl font-bold text-white">{profile.energy}</p>
          <p className="text-[10px] text-gray-500">Energy</p>
        </Card>
        <Card className="text-center !p-3">
          <Target className="w-5 h-5 text-emerald-400 mx-auto mb-1" />
          <p className="text-xl font-bold text-white">{Math.round(missionPct)}%</p>
          <p className="text-[10px] text-gray-500">Today</p>
        </Card>
        <Card className="text-center !p-3">
          <Trophy className="w-5 h-5 text-cyan-400 mx-auto mb-1" />
          <p className="text-xl font-bold text-white">{profile.life_level}</p>
          <p className="text-[10px] text-gray-500">Life Level</p>
        </Card>
      </div>

      {/* Daily Mission + Quests */}
      <div className="grid md:grid-cols-2 gap-4">
        {/* Daily Mission */}
        <Card>
          <h3 className="font-semibold text-white mb-1">Today's Mission</h3>
          <p className="text-xs text-gray-500 mb-4">Complete all to earn bonus XP</p>
          <div className="flex items-center gap-4 mb-4">
            <ProgressRing progress={missionPct} size={100} strokeWidth={7} color="#34d399">
              <div className="text-center">
                <p className="text-2xl font-bold text-white">{Math.round(missionPct)}%</p>
                <p className="text-[9px] text-gray-500">{missionDone}/{missionItems.length}</p>
              </div>
            </ProgressRing>
            <div className="flex-1 space-y-2">
              {missionItems.map((item, i) => {
                const Icon = item.icon;
                return (
                  <div key={i} className="flex items-center gap-2">
                    <Icon className={cn('w-4 h-4', item.done ? 'text-emerald-400' : 'text-gray-600')} />
                    <span className={cn('text-sm', item.done ? 'text-white' : 'text-gray-500')}>{item.label}</span>
                    {item.done && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 ml-auto" />}
                  </div>
                );
              })}
            </div>
          </div>
          <button onClick={logWater}
            className="w-full bg-cyan-500/10 text-cyan-400 border border-cyan-400/20 rounded-xl py-2 text-xs font-medium hover:bg-cyan-500/15 transition-all flex items-center justify-center gap-2">
            <Droplet className="w-3.5 h-3.5" /> Quick Add Water (+250ml)
          </button>
        </Card>

        {/* Daily Quests */}
        <Card>
          <div className="flex items-center justify-between mb-1">
            <h3 className="font-semibold text-white">Daily Quests</h3>
            <Badge color="yellow">{earnedQuestXp}/{totalQuestXp} XP</Badge>
          </div>
          <p className="text-xs text-gray-500 mb-4">{completedQuests}/{quests.length} completed</p>
          <div className="space-y-2">
            {quests.length === 0 && <p className="text-sm text-gray-600 py-4 text-center">No quests generated yet. Use the + button to generate.</p>}
            {quests.map(quest => (
              <button key={quest.id} onClick={() => toggleQuest(quest)}
                className={cn('w-full flex items-center gap-3 p-3 rounded-xl transition-all text-left',
                  quest.completed ? 'bg-emerald-400/10 border border-emerald-400/20' : 'bg-white/[0.03] border border-white/[0.06] hover:bg-white/[0.06]')}>
                {quest.completed ? <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0" /> : <Circle className="w-5 h-5 text-gray-600 shrink-0" />}
                <span className={cn('text-sm flex-1', quest.completed ? 'text-white line-through opacity-60' : 'text-gray-300')}>{quest.title}</span>
                <span className="text-xs font-bold text-yellow-400 shrink-0">+{quest.xp_reward}</span>
              </button>
            ))}
          </div>
        </Card>
      </div>

      {/* RPG Stats */}
      <Card>
        <h3 className="font-semibold text-white mb-4">Character Stats</h3>
        <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
          {stats.map(stat => (
            <div key={stat.label} className="flex flex-col items-center">
              <ProgressRing progress={stat.value} size={72} strokeWidth={6} color={stat.color}>
                <div className="text-center">
                  <p className="text-lg font-bold text-white">{stat.value}</p>
                </div>
              </ProgressRing>
              <p className="text-xs text-gray-400 mt-2">{stat.icon} {stat.label}</p>
            </div>
          ))}
        </div>
      </Card>

      {/* Today's Workout + AI Coach */}
      <div className="grid md:grid-cols-2 gap-4">
        <Card className={cn(todayWorkout && 'border-emerald-400/15')}>
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-semibold text-white">Today's Workout — {todayName}</h3>
            {todayWorkout && <Badge color="emerald">{todayWorkout.workout_type}</Badge>}
          </div>
          {todayWorkout ? (
            <div>
              <p className="text-lg font-medium text-white mb-2">{todayWorkout.title}</p>
              <div className="flex items-center gap-3 text-xs text-gray-400 mb-3">
                <span>{todayWorkout.exercises.length} exercises</span>
                <span>·</span>
                <span>{todayWorkout.duration_min} min</span>
                <span>·</span>
                <span>{todayWorkout.difficulty}</span>
                <span>·</span>
                <span>~{todayWorkout.calories} cal</span>
              </div>
              <div className="space-y-1.5 mb-4">
                {todayWorkout.exercises.slice(0, 3).map((ex, i) => (
                  <div key={i} className="flex items-center gap-2 text-sm text-gray-400">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400/50" />
                    {ex.name} — {ex.sets}×{ex.reps} @ {ex.weight_kg}kg
                  </div>
                ))}
                {todayWorkout.exercises.length > 3 && <p className="text-xs text-gray-600 ml-3.5">+{todayWorkout.exercises.length - 3} more</p>}
              </div>
              <button onClick={() => window.location.hash = 'workout'}
                className="w-full bg-gradient-to-r from-emerald-400 to-cyan-500 text-[#08080c] font-bold py-2.5 rounded-xl hover:opacity-90 transition-all text-sm flex items-center justify-center gap-2">
                <Dumbbell className="w-4 h-4" /> Start Workout
              </button>
            </div>
          ) : (
            <div className="text-center py-6">
              <p className="text-4xl mb-2">😴</p>
              <p className="text-sm text-gray-400">Rest day — focus on recovery</p>
              <p className="text-xs text-gray-600 mt-1">Light walk or stretching recommended</p>
            </div>
          )}
        </Card>

        {/* AI Coach */}
        <Card className="bg-gradient-to-br from-violet-500/5 via-transparent to-transparent border-violet-500/10">
          <div className="flex items-center gap-2 mb-3">
            <div className="w-8 h-8 rounded-lg bg-violet-500/15 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-violet-400" />
            </div>
            <h3 className="font-semibold text-white">AI Coach</h3>
          </div>
          <div className="space-y-3">
            {coachInsights.slice(0, 2).map((insight, i) => (
              <div key={i} className={cn('p-3 rounded-xl text-sm',
                insight.type === 'warning' ? 'bg-orange-500/10 border border-orange-500/15' :
                insight.type === 'recovery' ? 'bg-blue-500/10 border border-blue-500/15' :
                insight.type === 'progress' ? 'bg-emerald-500/10 border border-emerald-500/15' :
                'bg-white/[0.04]')}>
                <p className="text-gray-300 leading-relaxed">{insight.insight}</p>
              </div>
            ))}
          </div>
        </Card>
      </div>

      {/* Active Goals preview */}
      <Card>
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-semibold text-white">Active Goals</h3>
          <button onClick={() => window.location.hash = 'profile'} className="text-xs text-emerald-400 hover:text-emerald-300">View all →</button>
        </div>
        <div className="space-y-3">
          {goals.length === 0 && <p className="text-sm text-gray-600 text-center py-2">No active goals yet.</p>}
          {goals.map(goal => {
            const pct = Math.min(100, (goal.current_value / goal.target_value) * 100);
            return (
              <div key={goal.id}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-sm text-white">{goal.title}</span>
                  <span className="text-xs text-gray-500">{goal.current_value}/{goal.target_value} {goal.unit}</span>
                </div>
                <ProgressBar value={goal.current_value} max={goal.target_value} />
              </div>
            );
          })}
        </div>
      </Card>

      {/* Daily Check-in */}
      <Card>
        <div className="flex items-center justify-between">
          <div>
            <h3 className="font-semibold text-white">Daily Check-in</h3>
            <p className="text-xs text-gray-500 mt-0.5">How are you feeling today?</p>
          </div>
          <button onClick={() => setCheckInOpen(!checkInOpen)}
            className="text-xs text-emerald-400 hover:text-emerald-300 font-medium">
            {checkInOpen ? 'Close' : dailyLog?.energy_level ? 'Update' : 'Check in'}
          </button>
        </div>
        {checkInOpen && <CheckInForm onSave={saveCheckIn} current={dailyLog} />}
        {!checkInOpen && dailyLog?.energy_level && (
          <div className="flex items-center gap-3 mt-3 text-xs text-gray-400">
            <span>Energy: {['', 'Low', 'Normal', 'High'][dailyLog.energy_level]}</span>
            <span>Mood: {['', '😞', '😐', '🙂', '😄', '🤩'][dailyLog.mood]}</span>
            <span>Sleep: {dailyLog.sleep_hours}h</span>
          </div>
        )}
      </Card>

      {/* Recent badges */}
      {badges.length > 0 && (
        <Card>
          <h3 className="font-semibold text-white mb-4">Recent Achievements</h3>
          <div className="flex gap-3 overflow-x-auto pb-1">
            {badges.slice(0, 6).map(badge => (
              <div key={badge.id} className="flex flex-col items-center min-w-[80px]">
                <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-yellow-400/15 to-orange-500/15 border border-yellow-400/10 flex items-center justify-center text-2xl mb-1.5">
                  {badge.icon}
                </div>
                <p className="text-[10px] text-gray-400 text-center leading-tight">{badge.name}</p>
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}

function CheckInForm({ onSave, current }: { onSave: (energy: number, mood: number, stress: number, sleep: number) => void; current: DailyLog | null }) {
  const [energy, setEnergy] = useState(current?.energy_level || 2);
  const [mood, setMood] = useState(current?.mood || 3);
  const [stress, setStress] = useState(current?.stress_level || 2);
  const [sleep, setSleep] = useState(String(current?.sleep_hours || ''));

  return (
    <div className="mt-4 space-y-4">
      <div>
        <label className="block text-xs text-gray-400 mb-2">Energy Level</label>
        <div className="flex gap-2">
          {['⚡ Low', '🙂 Normal', '🔥 High'].map((label, i) => (
            <button key={i} onClick={() => setEnergy(i + 1)}
              className={cn('flex-1 py-2.5 rounded-xl text-xs font-medium transition-all', energy === i + 1 ? 'bg-emerald-400 text-[#08080c]' : 'bg-white/[0.04] text-gray-400 border border-white/[0.06]')}>
              {label}
            </button>
          ))}
        </div>
      </div>
      <div>
        <label className="block text-xs text-gray-400 mb-2">Mood</label>
        <div className="flex gap-2">
          {['😞', '😐', '🙂', '😄', '🤩'].map((emoji, i) => (
            <button key={i} onClick={() => setMood(i + 1)}
              className={cn('flex-1 py-2.5 rounded-xl text-lg transition-all', mood === i + 1 ? 'bg-emerald-400/20 border border-emerald-400/30' : 'bg-white/[0.04] border border-white/[0.06]')}>
              {emoji}
            </button>
          ))}
        </div>
      </div>
      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs text-gray-400 mb-2">Sleep (hours)</label>
          <input type="number" step="0.5" value={sleep} onChange={e => setSleep(e.target.value)} placeholder="7"
            className="w-full bg-white/[0.04] border border-white/[0.06] rounded-xl px-3 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
        </div>
        <div>
          <label className="block text-xs text-gray-400 mb-2">Stress Level</label>
          <div className="flex gap-1.5">
            {['Low', 'Med', 'High'].map((label, i) => (
              <button key={i} onClick={() => setStress(i + 1)}
                className={cn('flex-1 py-2.5 rounded-xl text-xs font-medium transition-all', stress === i + 1 ? 'bg-orange-400 text-[#08080c]' : 'bg-white/[0.04] text-gray-400 border border-white/[0.06]')}>
                {label}
              </button>
            ))}
          </div>
        </div>
      </div>
      <button onClick={() => onSave(energy, mood, stress, parseFloat(sleep) || 0)}
        className="w-full bg-gradient-to-r from-emerald-400 to-cyan-500 text-[#08080c] font-bold py-2.5 rounded-xl hover:opacity-90 transition-all text-sm">
        Save Check-in
      </button>
    </div>
  );
}

function DashboardSkeleton() {
  return (
    <div className="space-y-5 max-w-5xl mx-auto animate-pulse">
      <div className="h-10 w-80 bg-white/[0.04] rounded-xl" />
      <div className="grid grid-cols-4 gap-3">{Array.from({ length: 4 }).map((_, i) => <div key={i} className="h-20 bg-white/[0.04] rounded-2xl" />)}</div>
      <div className="grid md:grid-cols-2 gap-4">{Array.from({ length: 2 }).map((_, i) => <div key={i} className="h-64 bg-white/[0.04] rounded-2xl" />)}</div>
    </div>
  );
}
