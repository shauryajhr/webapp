import { useEffect, useState } from 'react';
import { Plus, X, Trash2, Clock, GripVertical } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { Card, Badge } from '@/components/ui/Card';
import { cn, getDayShort, todayDayOfWeek } from '@/lib/utils';
import type { ScheduleItem } from '@/types';

const CATEGORIES: Record<string, { color: string; icon: string }> = {
  fitness: { color: 'bg-emerald-400/10 border-emerald-400/20', icon: '🏋️' },
  nutrition: { color: 'bg-orange-400/10 border-orange-400/20', icon: '🍽️' },
  productivity: { color: 'bg-blue-400/10 border-blue-400/20', icon: '📚' },
  routine: { color: 'bg-violet-400/10 border-violet-400/20', icon: '⏰' },
  recovery: { color: 'bg-cyan-400/10 border-cyan-400/20', icon: '😴' },
  general: { color: 'bg-white/[0.04] border-white/[0.06]', icon: '📌' },
};

const CATEGORY_NAMES = Object.keys(CATEGORIES);

export default function Schedule() {
  const { profile } = useAuth();
  const [items, setItems] = useState<ScheduleItem[]>([]);
  const [selectedDay, setSelectedDay] = useState(todayDayOfWeek());
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState({ time: '08:00', title: '', category: 'general', duration_min: 60 });
  const [draggedId, setDraggedId] = useState<string | null>(null);

  useEffect(() => {
    if (!profile) return;
    supabase.from('schedule_items').select('*').eq('user_id', profile.id).order('time', { ascending: true })
      .then(({ data }) => { setItems(data as ScheduleItem[] || []); setLoading(false); });
  }, [profile]);

  const dayItems = items.filter(i => i.day_of_week === selectedDay).sort((a, b) => a.time.localeCompare(b.time));
  const days = [1, 2, 3, 4, 5, 6, 0];

  async function addItem() {
    if (!profile || !form.title.trim()) return;
    const { data } = await supabase.from('schedule_items').insert({
      user_id: profile.id, day_of_week: selectedDay, time: form.time, title: form.title,
      category: form.category, duration_min: form.duration_min,
    }).select('*').maybeSingle();
    if (data) setItems([...items, data as ScheduleItem]);
    setShowModal(false);
    setForm({ time: '08:00', title: '', category: 'general', duration_min: 60 });
  }

  async function deleteItem(id: string) {
    await supabase.from('schedule_items').delete().eq('id', id);
    setItems(items.filter(i => i.id !== id));
  }

  async function updateTime(id: string, newTime: string) {
    await supabase.from('schedule_items').update({ time: newTime }).eq('id', id);
    setItems(items.map(i => i.id === id ? { ...i, time: newTime } : i));
  }

  if (loading) return <div className="space-y-4 animate-pulse"><div className="h-10 w-60 bg-white/[0.04] rounded-xl" /><div className="h-96 bg-white/[0.04] rounded-2xl" /></div>;

  return (
    <div className="space-y-5 max-w-3xl mx-auto">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white">Life Schedule</h1>
          <p className="text-sm text-gray-400 mt-1">Your daily timeline — fitness, nutrition, productivity</p>
        </div>
        <button onClick={() => setShowModal(true)}
          className="bg-gradient-to-r from-emerald-400 to-cyan-500 text-[#08080c] font-bold px-4 py-2.5 rounded-xl hover:opacity-90 transition-all flex items-center gap-2 text-sm">
          <Plus className="w-4 h-4" /> Add
        </button>
      </div>

      {/* Day selector */}
      <div className="flex gap-2 overflow-x-auto pb-1">
        {days.map(dow => {
          const isSelected = dow === selectedDay;
          const isToday = dow === todayDayOfWeek();
          return (
            <button key={dow} onClick={() => setSelectedDay(dow)}
              className={cn('px-4 py-2.5 rounded-xl text-sm font-medium transition-all border',
                isSelected ? 'bg-emerald-400/10 border-emerald-400/30 text-emerald-400' : 'bg-white/[0.03] border-white/[0.06] text-gray-400 hover:bg-white/[0.06]')}>
              {getDayShort(dow)} {isToday && <span className="ml-1 text-[10px] bg-emerald-400 text-[#08080c] px-1.5 rounded-full">TODAY</span>}
            </button>
          );
        })}
      </div>

      {/* Timeline */}
      <Card className="!p-4">
        {dayItems.length === 0 ? (
          <div className="text-center py-12">
            <p className="text-3xl mb-2">📅</p>
            <p className="text-sm text-gray-400">No activities scheduled for this day</p>
            <button onClick={() => setShowModal(true)} className="text-xs text-emerald-400 hover:text-emerald-300 mt-2 font-medium">Add your first activity</button>
          </div>
        ) : (
          <div className="relative">
            {/* Timeline line */}
            <div className="absolute left-[60px] top-0 bottom-0 w-px bg-white/[0.06]" />
            <div className="space-y-2">
              {dayItems.map(item => {
                const cat = CATEGORIES[item.category] || CATEGORIES.general;
                return (
                  <div key={item.id} className="flex items-start gap-3 group relative">
                    {/* Time */}
                    <div className="w-14 text-right pt-3">
                      <p className="text-xs font-medium text-gray-400">{item.time}</p>
                    </div>
                    {/* Dot */}
                    <div className="relative pt-4">
                      <div className={cn('w-3 h-3 rounded-full border-2', cat.color)} />
                    </div>
                    {/* Card */}
                    <div className={cn('flex-1 rounded-xl border p-3 transition-all', cat.color)}>
                      <div className="flex items-center gap-2">
                        <span className="text-base">{cat.icon}</span>
                        <p className="text-sm font-medium text-white flex-1">{item.title}</p>
                        <span className="text-[10px] text-gray-500 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {item.duration_min}min
                        </span>
                        <button onClick={() => deleteItem(item.id)}
                          className="text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-all">
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </Card>

      {/* Quick suggestions */}
      <Card>
        <h3 className="font-semibold text-white mb-3">Smart Suggestions</h3>
        <div className="space-y-2">
          {[
            { time: '06:30', title: 'Wake Up & Hydrate', category: 'routine', icon: '⏰' },
            { time: '07:00', title: 'Morning Walk / Sunlight', category: 'fitness', icon: '🏃' },
            { time: '22:30', title: 'Wind Down — No Screens', category: 'recovery', icon: '🌙' },
          ].map(s => (
            <button key={s.title} onClick={() => { setForm({ time: s.time, title: s.title, category: s.category, duration_min: 30 }); setShowModal(true); }}
              className="w-full flex items-center gap-3 p-3 bg-white/[0.03] rounded-xl hover:bg-white/[0.06] transition-all text-left">
              <span className="text-lg">{s.icon}</span>
              <div className="flex-1">
                <p className="text-sm text-white">{s.title}</p>
                <p className="text-xs text-gray-500">{s.time}</p>
              </div>
              <Plus className="w-4 h-4 text-gray-600" />
            </button>
          ))}
        </div>
      </Card>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm" onClick={() => setShowModal(false)}>
          <div className="bg-[#13131c] border border-white/[0.08] rounded-3xl p-6 w-full max-w-md" onClick={e => e.stopPropagation()}>
            <div className="flex items-center justify-between mb-5">
              <h3 className="font-semibold text-white text-lg">New Activity</h3>
              <button onClick={() => setShowModal(false)} className="text-gray-400 hover:text-white"><X className="w-5 h-5" /></button>
            </div>
            <div className="space-y-4">
              <div>
                <label className="block text-xs text-gray-400 mb-1.5">Activity Title</label>
                <input value={form.title} onChange={e => setForm({ ...form, title: e.target.value })} placeholder="e.g. Morning Workout"
                  className="w-full bg-white/[0.04] border border-white/[0.06] rounded-xl px-3.5 py-2.5 text-sm text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
              </div>
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs text-gray-400 mb-1.5">Time</label>
                  <input type="time" value={form.time} onChange={e => setForm({ ...form, time: e.target.value })}
                    className="w-full bg-white/[0.04] border border-white/[0.06] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-400/40" />
                </div>
                <div>
                  <label className="block text-xs text-gray-400 mb-1.5">Duration (min)</label>
                  <input type="number" value={form.duration_min} onChange={e => setForm({ ...form, duration_min: parseInt(e.target.value) || 60 })}
                    className="w-full bg-white/[0.04] border border-white/[0.06] rounded-xl px-3.5 py-2.5 text-sm text-white focus:outline-none focus:border-emerald-400/40" />
                </div>
              </div>
              <div>
                <label className="block text-xs text-gray-400 mb-1.5">Category</label>
                <div className="flex flex-wrap gap-2">
                  {CATEGORY_NAMES.map(cat => (
                    <button key={cat} onClick={() => setForm({ ...form, category: cat })}
                      className={cn('px-3 py-2 rounded-xl text-xs font-medium transition-all border',
                        form.category === cat ? CATEGORIES[cat].color + ' text-white' : 'bg-white/[0.03] border-white/[0.06] text-gray-400')}>
                      {CATEGORIES[cat].icon} {cat}
                    </button>
                  ))}
                </div>
              </div>
              <button onClick={addItem} disabled={!form.title.trim()}
                className="w-full bg-gradient-to-r from-emerald-400 to-cyan-500 text-[#08080c] font-bold py-2.5 rounded-xl hover:opacity-90 transition-all disabled:opacity-50 text-sm">
                Add Activity
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
