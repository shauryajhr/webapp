import { useState } from 'react';
import { AuthProvider, useAuth } from '@/lib/auth';
import Auth from '@/components/Auth';
import Onboarding from '@/components/Onboarding';
import BottomNav, { type Page } from '@/components/BottomNav';
import Dashboard from '@/pages/Dashboard';
import Workout from '@/pages/Workout';
import Schedule from '@/pages/Schedule';
import Growth from '@/pages/Growth';
import Profile from '@/pages/Profile';

function AppContent() {
  const { session, profile, loading } = useAuth();
  const [page, setPage] = useState<Page>('dashboard');

  if (loading) {
    return (
      <div className="min-h-screen bg-[#08080c] flex items-center justify-center">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 rounded-2xl bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center animate-pulse">
            <svg className="w-7 h-7 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
              <path d="M6.5 6.5L17.5 17.5M17.5 6.5L6.5 17.5M12 3L13.5 8.5L19 10L13.5 11.5L12 17L10.5 11.5L5 10L10.5 8.5L12 3Z" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </div>
          <p className="text-sm text-gray-500">Loading LevelUp...</p>
        </div>
      </div>
    );
  }

  if (!session) return <Auth />;
  if (profile && !profile.onboarding_complete) return <Onboarding />;

  return (
    <div className="min-h-screen bg-[#08080c] text-white">
      <main className="px-4 lg:px-6 py-6 pb-28 max-w-5xl mx-auto">
        {page === 'dashboard' && <Dashboard />}
        {page === 'workout' && <Workout />}
        {page === 'schedule' && <Schedule />}
        {page === 'growth' && <Growth />}
        {page === 'profile' && <Profile />}
      </main>
      <BottomNav current={page} onNavigate={setPage} />
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}
