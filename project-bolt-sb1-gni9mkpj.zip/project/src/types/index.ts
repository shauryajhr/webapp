export interface Profile {
  id: string;
  name: string | null;
  age: number | null;
  height_cm: number | null;
  weight_kg: number | null;
  fitness_goal: string | null;
  activity_level: string | null;
  experience_level: string | null;
  daily_available_time: string | null;
  sleep_target_hours: number;
  personal_goals: string | null;
  xp: number;
  level: number;
  onboarding_complete: boolean;
  strength: number;
  health: number;
  discipline: number;
  energy: number;
  consistency: number;
  life_level: number;
  created_at: string;
  updated_at: string;
}

export interface Exercise {
  name: string;
  sets: number;
  reps: string;
  weight_kg: number;
  rest_sec: number;
}

export interface Workout {
  id: string;
  user_id: string;
  day_of_week: number;
  workout_type: string;
  title: string;
  exercises: Exercise[];
  duration_min: number;
  difficulty: string;
  calories: number;
  created_at: string;
}

export interface WorkoutLog {
  id: string;
  user_id: string;
  date: string;
  workout_type: string;
  exercises_completed: Exercise[];
  duration_min: number;
  calories_burned: number;
  xp_earned: number;
  created_at: string;
}

export interface DailyLog {
  id: string;
  user_id: string;
  date: string;
  steps: number;
  water_liters: number;
  sleep_hours: number;
  calories_eaten: number;
  protein_g: number;
  carbs_g: number;
  fats_g: number;
  energy_level: number;
  mood: number;
  stress_level: number;
  study_hours: number;
  screen_time_hours: number;
  meditation_minutes: number;
  workout_completed: boolean;
  daily_quests_completed: boolean;
  created_at: string;
}

export type GoalStatus = 'active' | 'completed' | 'abandoned';

export interface Goal {
  id: string;
  user_id: string;
  type: string;
  title: string;
  target_value: number;
  current_value: number;
  unit: string;
  deadline: string | null;
  streak: number;
  status: GoalStatus;
  created_at: string;
}

export interface Habit {
  id: string;
  user_id: string;
  name: string;
  icon: string;
  frequency: string;
  target_count: number;
  current_count: number;
  streak: number;
  active: boolean;
  created_at: string;
}

export interface HabitLog {
  id: string;
  user_id: string;
  habit_id: string;
  date: string;
  completed: boolean;
  created_at: string;
}

export interface Quest {
  id: string;
  user_id: string;
  date: string;
  title: string;
  quest_type: string;
  xp_reward: number;
  completed: boolean;
  created_at: string;
}

export interface ScheduleItem {
  id: string;
  user_id: string;
  day_of_week: number;
  time: string;
  title: string;
  category: string;
  duration_min: number;
  sort_order: number;
  created_at: string;
}

export interface BodyMetric {
  id: string;
  user_id: string;
  date: string;
  weight_kg: number | null;
  chest_cm: number | null;
  waist_cm: number | null;
  arm_cm: number | null;
  pushups_max: number | null;
  notes: string | null;
  created_at: string;
}

export interface Badge {
  id: string;
  user_id: string;
  badge_type: string;
  name: string;
  description: string | null;
  icon: string;
  earned_at: string;
}

export interface AIInsight {
  id: string;
  user_id: string;
  insight: string;
  insight_type: string;
  date: string;
  created_at: string;
}
