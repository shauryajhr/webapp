import { cn } from '@/lib/utils';
import type { ReactNode } from 'react';

export function Card({ children, className, onClick, hover }: { children: ReactNode; className?: string; onClick?: () => void; hover?: boolean }) {
  return (
    <div onClick={onClick}
      className={cn('bg-white/[0.03] backdrop-blur-sm border border-white/[0.06] rounded-2xl p-5',
        hover && 'hover:border-white/[0.12] hover:bg-white/[0.05] transition-all cursor-pointer',
        onClick && 'cursor-pointer',
        className
      )}>
      {children}
    </div>
  );
}

interface RingProps {
  progress: number;
  size?: number;
  strokeWidth?: number;
  color?: string;
  bgColor?: string;
  children?: ReactNode;
  className?: string;
}

export function ProgressRing({ progress, size = 120, strokeWidth = 8, color = '#34d399', bgColor = 'rgba(255,255,255,0.06)', children, className }: RingProps) {
  const radius = (size - strokeWidth) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (progress / 100) * circumference;
  return (
    <div className={cn('relative inline-flex items-center justify-center', className)} style={{ width: size, height: size }}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={bgColor} strokeWidth={strokeWidth} />
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke={color} strokeWidth={strokeWidth}
          strokeDasharray={circumference} strokeDashoffset={offset} strokeLinecap="round"
          style={{ transition: 'stroke-dashoffset 0.8s ease-out' }} />
      </svg>
      <div className="absolute inset-0 flex items-center justify-center">{children}</div>
    </div>
  );
}

export function ProgressBar({ value, max, color = 'from-emerald-400 to-cyan-500', className }: { value: number; max: number; color?: string; className?: string }) {
  const pct = Math.min(100, max > 0 ? (value / max) * 100 : 0);
  return (
    <div className={cn('h-2 bg-white/[0.06] rounded-full overflow-hidden', className)}>
      <div className={cn('h-full bg-gradient-to-r rounded-full transition-all duration-700', color)} style={{ width: `${pct}%` }} />
    </div>
  );
}

export function StatPill({ icon, label, value, color = 'text-emerald-400' }: { icon: string; label: string; value: string; color?: string }) {
  return (
    <div className="flex items-center gap-2 bg-white/[0.04] rounded-xl px-3 py-2">
      <span className="text-lg">{icon}</span>
      <div>
        <p className={cn('text-sm font-bold', color)}>{value}</p>
        <p className="text-[10px] text-gray-500">{label}</p>
      </div>
    </div>
  );
}

export function Badge({ children, color = 'gray' }: { children: ReactNode; color?: 'emerald' | 'cyan' | 'orange' | 'red' | 'yellow' | 'gray' }) {
  const colors: Record<string, string> = {
    emerald: 'bg-emerald-400/10 text-emerald-400 border-emerald-400/20',
    cyan: 'bg-cyan-400/10 text-cyan-400 border-cyan-400/20',
    orange: 'bg-orange-400/10 text-orange-400 border-orange-400/20',
    red: 'bg-red-400/10 text-red-400 border-red-400/20',
    yellow: 'bg-yellow-400/10 text-yellow-400 border-yellow-400/20',
    gray: 'bg-white/5 text-gray-400 border-white/10',
  };
  return <span className={cn('inline-flex items-center px-2.5 py-1 rounded-full text-xs font-medium border', colors[color])}>{children}</span>;
}
