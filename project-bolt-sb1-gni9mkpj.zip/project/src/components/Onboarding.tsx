import { useState } from 'react';
import { useAuth } from '@/lib/auth';
import { supabase } from '@/lib/supabase';

const FITNESS_GOALS = ['Lose weight', 'Build muscle', 'Get stronger', 'Improve endurance', 'Stay fit', 'General health'];
const ACTIVITY_LEVELS = ['Sedentary', 'Lightly active', 'Moderately active', 'Very active', 'Athlete'];
const EXPERIENCE = ['Beginner', 'Intermediate', 'Advanced', 'Elite'];
const TIMES = ['30 min', '45 min', '1 hour', '1.5 hours', '2+ hours'];
const PERSONAL_GOALS = ['Lose 5 KG', 'Run 5K', 'Build discipline', 'Sleep better', 'Read more', 'Build a project'];

export default function Onboarding() {
  const { profile, updateProfile } = useAuth();
  const [step, setStep] = useState(0);
  const [name, setName] = useState('');
  const [age, setAge] = useState('');
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const [goal, setGoal] = useState('');
  const [activity, setActivity] = useState('');
  const [experience, setExperience] = useState('');
  const [time, setTime] = useState('');
  const [sleepTarget, setSleepTarget] = useState('7');
  const [personalGoals, setPersonalGoals] = useState<string[]>([]);
  const [saving, setSaving] = useState(false);

  const totalSteps = 5;

  function toggleGoal(g: string) {
    setPersonalGoals(prev => prev.includes(g) ? prev.filter(x => x !== g) : [...prev, g]);
  }

  async function handleFinish() {
    setSaving(true);
    await updateProfile({
      name,
      age: parseInt(age) || null,
      height_cm: parseFloat(height) || null,
      weight_kg: parseFloat(weight) || null,
      fitness_goal: goal,
      activity_level: activity,
      experience_level: experience,
      daily_available_time: time,
      sleep_target_hours: parseFloat(sleepTarget) || 7,
      personal_goals: personalGoals.join(', '),
      onboarding_complete: true,
    });
    setSaving(false);
  }

  const steps = [
    {
      title: 'What is your name?',
      subtitle: 'Let\'s create your character profile.',
      content: (
        <input value={name} onChange={e => setName(e.target.value)} placeholder="Enter your name" autoFocus
          className="w-full bg-white/[0.04] border border-white/[0.08] rounded-xl px-4 py-3.5 text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40 text-lg" />
      ),
      canProceed: name.trim().length > 0,
    },
    {
      title: 'Tell us about yourself',
      subtitle: 'Your basic stats help us personalize your plan.',
      content: (
        <div className="grid grid-cols-3 gap-3">
          <div>
            <label className="block text-xs text-gray-400 mb-1.5">Age</label>
            <input type="number" value={age} onChange={e => setAge(e.target.value)} placeholder="25"
              className="w-full bg-white/[0.04] border border-white/[0.08] rounded-xl px-3 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1.5">Height (cm)</label>
            <input type="number" value={height} onChange={e => setHeight(e.target.value)} placeholder="175"
              className="w-full bg-white/[0.04] border border-white/[0.08] rounded-xl px-3 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-1.5">Weight (kg)</label>
            <input type="number" value={weight} onChange={e => setWeight(e.target.value)} placeholder="80"
              className="w-full bg-white/[0.04] border border-white/[0.08] rounded-xl px-3 py-3 text-white placeholder-gray-600 focus:outline-none focus:border-emerald-400/40" />
          </div>
        </div>
      ),
      canProceed: age.length > 0 && height.length > 0 && weight.length > 0,
    },
    {
      title: 'What is your fitness goal?',
      subtitle: 'This shapes your workout plan and recommendations.',
      content: (
        <div className="space-y-2">
          {FITNESS_GOALS.map(g => (
            <button key={g} onClick={() => setGoal(g)}
              className={`w-full text-left px-4 py-3.5 rounded-xl text-sm font-medium transition-all ${goal === g ? 'bg-emerald-400 text-[#08080c]' : 'bg-white/[0.04] text-gray-300 border border-white/[0.08] hover:bg-white/[0.08]'}`}>
              {g}
            </button>
          ))}
        </div>
      ),
      canProceed: goal.length > 0,
    },
    {
      title: 'Your experience & schedule',
      subtitle: 'We\'ll match workouts to your level and available time.',
      content: (
        <div className="space-y-4">
          <div>
            <label className="block text-xs text-gray-400 mb-2">Activity Level</label>
            <div className="flex flex-wrap gap-2">
              {ACTIVITY_LEVELS.map(a => (
                <button key={a} onClick={() => setActivity(a)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${activity === a ? 'bg-emerald-400 text-[#08080c]' : 'bg-white/[0.04] text-gray-300 border border-white/[0.08]'}`}>
                  {a}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-2">Workout Experience</label>
            <div className="flex flex-wrap gap-2">
              {EXPERIENCE.map(ex => (
                <button key={ex} onClick={() => setExperience(ex)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${experience === ex ? 'bg-emerald-400 text-[#08080c]' : 'bg-white/[0.04] text-gray-300 border border-white/[0.08]'}`}>
                  {ex}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-2">Daily Available Time</label>
            <div className="flex flex-wrap gap-2">
              {TIMES.map(t => (
                <button key={t} onClick={() => setTime(t)}
                  className={`px-3.5 py-2 rounded-xl text-xs font-medium transition-all ${time === t ? 'bg-emerald-400 text-[#08080c]' : 'bg-white/[0.04] text-gray-300 border border-white/[0.08]'}`}>
                  {t}
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="block text-xs text-gray-400 mb-2">Sleep Target (hours): {sleepTarget}h</label>
            <input type="range" min="5" max="10" step="0.5" value={sleepTarget} onChange={e => setSleepTarget(e.target.value)}
              className="w-full accent-emerald-400" />
          </div>
        </div>
      ),
      canProceed: activity.length > 0 && experience.length > 0 && time.length > 0,
    },
    {
      title: 'What are your personal goals?',
      subtitle: 'Beyond fitness — what do you want to achieve?',
      content: (
        <div className="space-y-2">
          {PERSONAL_GOALS.map(g => (
            <button key={g} onClick={() => toggleGoal(g)}
              className={`w-full text-left px-4 py-3.5 rounded-xl text-sm font-medium transition-all flex items-center justify-between ${personalGoals.includes(g) ? 'bg-emerald-400/15 text-emerald-400 border border-emerald-400/30' : 'bg-white/[0.04] text-gray-300 border border-white/[0.08] hover:bg-white/[0.08]'}`}>
              {g}
              {personalGoals.includes(g) && <span className="text-emerald-400">✓</span>}
            </button>
          ))}
        </div>
      ),
      canProceed: personalGoals.length > 0,
    },
  ];

  const current = steps[step];

  return (
    <div className="min-h-screen bg-[#08080c] flex items-center justify-center px-4 relative overflow-hidden">
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[-10%] left-[5%] w-[500px] h-[500px] bg-emerald-500/10 rounded-full blur-[150px]" />
        <div className="absolute bottom-[-10%] right-[5%] w-[400px] h-[400px] bg-cyan-500/10 rounded-full blur-[150px]" />
      </div>

      <div className="relative w-full max-w-lg">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-emerald-400 to-cyan-500 flex items-center justify-center">
              <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                <path d="M6.5 6.5L17.5 17.5M17.5 6.5L6.5 17.5M12 3L13.5 8.5L19 10L13.5 11.5L12 17L10.5 11.5L5 10L10.5 8.5L12 3Z" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
            <span className="text-lg font-bold text-white">LevelUp</span>
          </div>
          <span className="text-sm text-gray-400">Step {step + 1} of {totalSteps}</span>
        </div>

        <div className="h-1.5 bg-white/[0.06] rounded-full mb-8 overflow-hidden">
          <div className="h-full bg-gradient-to-r from-emerald-400 to-cyan-500 rounded-full transition-all duration-500"
            style={{ width: `${((step + 1) / totalSteps) * 100}%` }} />
        </div>

        <div className="bg-white/[0.03] backdrop-blur-xl border border-white/[0.08] rounded-3xl p-8">
          <h2 className="text-xl font-bold text-white mb-1">{current.title}</h2>
          <p className="text-sm text-gray-400 mb-6">{current.subtitle}</p>
          {current.content}
          <div className="flex gap-3 mt-8">
            {step > 0 && (
              <button onClick={() => setStep(step - 1)}
                className="px-5 py-3 rounded-xl text-sm font-medium text-gray-300 bg-white/[0.04] border border-white/[0.08] hover:bg-white/[0.08] transition-all">
                Back
              </button>
            )}
            {step < totalSteps - 1 ? (
              <button onClick={() => setStep(step + 1)} disabled={!current.canProceed}
                className="flex-1 px-5 py-3 rounded-xl text-sm font-bold text-[#08080c] bg-gradient-to-r from-emerald-400 to-cyan-500 hover:opacity-90 transition-all disabled:opacity-40 disabled:cursor-not-allowed">
                Continue
              </button>
            ) : (
              <button onClick={handleFinish} disabled={!current.canProceed || saving}
                className="flex-1 px-5 py-3 rounded-xl text-sm font-bold text-[#08080c] bg-gradient-to-r from-emerald-400 to-cyan-500 hover:opacity-90 transition-all disabled:opacity-40">
                {saving ? 'Creating your profile...' : 'Start My Journey'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
