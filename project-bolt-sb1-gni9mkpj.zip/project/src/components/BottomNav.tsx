import { Home, Dumbbell, Calendar, TrendingUp, User, Plus } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/lib/auth';
import { generateDailyQuests } from '@/lib/gamification';
import { todayStr } from '@/lib/utils';

export type Page = 'dashboard' | 'workout' | 'schedule' | 'growth' | 'profile';

const NAV_ITEMS: { id: Page; label: string; icon: typeof Home }[] = [
  { id: 'dashboard', label: 'Home', icon: Home },
  { id: 'workout', label: 'Workout', icon: Dumbbell },
  { id: 'schedule', label: 'Schedule', icon: Calendar },
  { id: 'growth', label: 'Growth', icon: TrendingUp },
  { id: 'profile', label: 'Profile', icon: User },
];

interface Props {
  current: Page;
  onNavigate: (page: Page) => void;
}

export default function BottomNav({ current, onNavigate }: Props) {
  const [fabOpen, setFabOpen] = useState(false);
  const { profile } = useAuth();

  async function quickAddWorkout() {
    setFabOpen(false);
    onNavigate('workout');
  }

  async function quickAddWater() {
    setFabOpen(false);
    if (!profile) return;
    const today = todayStr();
    const { data: existing } = await supabase.from('daily_logs').select('*').eq('user_id', profile.id).eq('date', today).maybeSingle();
    if (existing) {
      await supabase.from('daily_logs').update({ water_liters: +(existing.water_liters + 0.25).toFixed(2) }).eq('id', existing.id);
    } else {
      await supabase.from('daily_logs').insert({ user_id: profile.id, date: today, water_liters: 0.25 });
    }
    window.location.reload();
  }

  async function quickAddGoal() {
    setFabOpen(false);
    onNavigate('profile');
  }

  async function quickAddHabit() {
    setFabOpen(false);
    if (!profile) return;
    onNavigate('dashboard');
  }

  async function quickGenerateQuests() {
    setFabOpen(false);
    if (!profile) return;
    const today = todayStr();
    const { data: existing } = await supabase.from('quests').select('*').eq('user_id', profile.id).eq('date', today);
    if (!existing || existing.length === 0) {
      const quests = generateDailyQuests(profile);
      await supabase.from('quests').insert(quests.map(q => ({
        user_id: profile.id, date: today, title: q.title, quest_type: q.quest_type, xp_reward: q.xp_reward, completed: false,
      })));
    }
    onNavigate('dashboard');
  }

  const fabActions = [
    { label: 'Start Workout', icon: '🏋️', onClick: quickAddWorkout },
    { label: 'Add Water (+250ml)', icon: '💧', onClick: quickAddWater },
    { label: 'New Goal', icon: '🎯', onClick: quickAddGoal },
    { label: 'New Habit', icon: '🔥', onClick: quickAddHabit },
    { label: 'Generate Quests', icon: '⚔️', onClick: quickGenerateQuests },
  ];

  return (
    <>
      {/* Floating Action Button */}
      <div className="fixed bottom-24 lg:bottom-8 right-4 lg:right-8 z-50 flex flex-col items-end gap-2">
        {fabOpen && (
          <div className="flex flex-col gap-2 mb-2 animate-[fadeIn_0.2s_ease-out]">
            {fabActions.map(action => (
              <button key={action.label} onClick={action.onClick}
                className="flex items-center gap-3 bg-[#13131c] border border-white/10 rounded-2xl pl-3 pr-5 py-2.5 hover:bg-white/[0.08] transition-all group">
                <span className="text-xl">{action.icon}</span>
                <span className="text-sm text-white font-medium">{action.label}</span>
              </button>
            ))}
          </div>
        )}
        <button onClick={() => setFabOpen(!fabOpen)}
          className={cn('w-14 h-14 rounded-2xl flex items-center justify-center shadow-lg transition-all',
            fabOpen ? 'bg-white text-[#08080c] rotate-45' : 'bg-gradient-to-br from-emerald-400 to-cyan-500 text-[#08080c] shadow-emerald-500/20')}>
          <Plus className="w-7 h-7" />
        </button>
      </div>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-0 left-0 right-0 z-40 bg-[#0a0a12]/95 backdrop-blur-xl border-t border-white/[0.06]">
        <div className="flex justify-around items-center px-2 py-2 max-w-2xl mx-auto">
          {NAV_ITEMS.map(item => {
            const Icon = item.icon;
            const active = current === item.id;
            return (
              <button key={item.id} onClick={() => onNavigate(item.id)}
                className={cn('flex flex-col items-center gap-1 px-4 py-1.5 rounded-xl transition-all', active ? 'text-emerald-400' : 'text-gray-500 hover:text-gray-300')}>
                <Icon className="w-5 h-5" />
                <span className="text-[10px] font-medium">{item.label}</span>
                {active && <div className="w-1 h-1 rounded-full bg-emerald-400 -mt-0.5" />}
              </button>
            );
          })}
        </div>
      </nav>
    </>
  );
}
