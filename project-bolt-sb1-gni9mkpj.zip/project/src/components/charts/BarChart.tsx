interface Props {
  data: { label: string; value: number; value2?: number }[];
  height?: number;
  color?: string;
  color2?: string;
  formatValue?: (v: number) => string;
}

export default function BarChart({ data, height = 200, color = '#34d399', color2 = 'rgba(255,255,255,0.2)', formatValue }: Props) {
  if (data.length === 0) return <div style={{ height }} className="flex items-center justify-center text-gray-600 text-sm">No data yet</div>;
  const allValues = data.flatMap(d => [d.value, d.value2 ?? 0]);
  const max = Math.max(...allValues, 1);

  return (
    <div>
      <div className="flex items-end justify-between gap-2" style={{ height }}>
        {data.map((d, i) => (
          <div key={i} className="flex-1 flex flex-col items-center justify-end h-full group">
            <div className="w-full flex items-end justify-center gap-1 h-full">
              <div className="w-full max-w-[24px] rounded-t-md transition-all hover:opacity-80 relative"
                style={{ height: `${(d.value / max) * 100}%`, backgroundColor: color, minHeight: '2px' }}>
                <div className="absolute -top-7 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity text-[10px] text-white whitespace-nowrap bg-black/80 px-1.5 py-0.5 rounded">
                  {formatValue ? formatValue(d.value) : d.value}
                </div>
              </div>
              {d.value2 !== undefined && (
                <div className="w-full max-w-[24px] rounded-t-md transition-all hover:opacity-80 relative"
                  style={{ height: `${(d.value2 / max) * 100}%`, backgroundColor: color2, minHeight: '2px' }}>
                  <div className="absolute -top-7 left-1/2 -translate-x-1/2 opacity-0 group-hover:opacity-100 transition-opacity text-[10px] text-white whitespace-nowrap bg-black/80 px-1.5 py-0.5 rounded">
                    {formatValue ? formatValue(d.value2) : d.value2}
                  </div>
                </div>
              )}
            </div>
          </div>
        ))}
      </div>
      <div className="flex justify-between mt-2 text-[10px] text-gray-600">
        {data.map((d, i) => <span key={i} className="flex-1 text-center">{d.label}</span>)}
      </div>
    </div>
  );
}
