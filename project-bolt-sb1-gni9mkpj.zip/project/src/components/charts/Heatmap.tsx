interface Cell {
  date: string;
  value: number;
}

interface Props {
  cells: Cell[];
  weeks?: number;
  maxValue?: number;
}

export default function Heatmap({ cells, weeks = 13, maxValue }: Props) {
  const cellMap = new Map(cells.map(c => [c.date, c.value]));
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const days: { date: string; value: number }[][] = [];
  for (let w = weeks - 1; w >= 0; w--) {
    const weekDays: { date: string; value: number }[] = [];
    for (let d = 6; d >= 0; d--) {
      const date = new Date(today);
      date.setDate(date.getDate() - (w * 7 + d));
      const dateStr = date.toISOString().split('T')[0];
      weekDays.push({ date: dateStr, value: cellMap.get(dateStr) || 0 });
    }
    days.push(weekDays);
  }

  const max = maxValue || Math.max(...cells.map(c => c.value), 1);

  function getColor(value: number): string {
    if (value === 0) return 'bg-white/[0.04]';
    const intensity = value / max;
    if (intensity > 0.75) return 'bg-emerald-400';
    if (intensity > 0.5) return 'bg-emerald-400/70';
    if (intensity > 0.25) return 'bg-emerald-400/40';
    return 'bg-emerald-400/20';
  }

  return (
    <div className="flex gap-1 overflow-x-auto">
      {days.map((week, wi) => (
        <div key={wi} className="flex flex-col gap-1">
          {week.map((day) => (
            <div key={day.date}
              className={`w-3 h-3 rounded-sm ${getColor(day.value)} transition-all hover:ring-1 hover:ring-white/30`}
              title={`${day.date}: ${day.value > 0 ? Math.round(day.value) + '%' : 'No activity'}`}
            />
          ))}
        </div>
      ))}
    </div>
  );
}
