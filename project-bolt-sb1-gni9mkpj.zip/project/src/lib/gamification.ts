import type { Profile } from '@/types';
import { levelFromXp, calculateLifeLevel } from './utils';

export interface XPAction {
  action: string;
  xp: number;
  statBoosts: Partial<Record<'strength' | 'health' | 'discipline' | 'energy' | 'consistency', number>>;
}

export const XP_REWARDS: Record<string, XPAction> = {
  workout: { action: 'Complete workout', xp: 100, statBoosts: { strength: 3, discipline: 2, energy: 1 } },
  steps_10k: { action: '10K steps', xp: 50, statBoosts: { health: 1, energy: 1 } },
  healthy_meal: { action: 'Healthy meal', xp: 30, statBoosts: { health: 1 } },
  study_1h: { action: 'Study 1 hour', xp: 40, statBoosts: { discipline: 1 } },
  sleep_7h: { action: 'Sleep 7+ hours', xp: 50, statBoosts: { health: 1, energy: 2 } },
  water_2l: { action: 'Drink 2L water', xp: 30, statBoosts: { health: 1 } },
  meditation: { action: 'Meditate', xp: 40, statBoosts: { discipline: 1, energy: 1 } },
  all_quests: { action: 'Complete all daily quests', xp: 150, statBoosts: { discipline: 3, consistency: 3 } },
  habit_complete: { action: 'Complete a habit', xp: 20, statBoosts: { consistency: 1 } },
};

export interface LevelUpResult {
  leveledUp: boolean;
  newLevel: number;
  xpGained: number;
  statChanges: Partial<Record<'strength' | 'health' | 'discipline' | 'energy' | 'consistency', number>>;
}

export function applyXpGain(profile: Profile, xpAmount: number, statBoosts?: Partial<Record<'strength' | 'health' | 'discipline' | 'energy' | 'consistency', number>>): { profile: Partial<Profile>; result: LevelUpResult } {
  const oldLevelInfo = levelFromXp(profile.xp);
  const newXp = profile.xp + xpAmount;
  const newLevelInfo = levelFromXp(newXp);

  const statChanges = statBoosts || {};
  const newStats = {
    strength: Math.min(100, profile.strength + (statChanges.strength || 0)),
    health: Math.min(100, profile.health + (statChanges.health || 0)),
    discipline: Math.min(100, profile.discipline + (statChanges.discipline || 0)),
    energy: Math.min(100, profile.energy + (statChanges.energy || 0)),
    consistency: Math.min(100, profile.consistency + (statChanges.consistency || 0)),
  };

  const lifeLevel = calculateLifeLevel(newStats);

  return {
    profile: {
      xp: newXp,
      level: newLevelInfo.level,
      ...newStats,
      life_level: lifeLevel,
    },
    result: {
      leveledUp: newLevelInfo.level > oldLevelInfo.level,
      newLevel: newLevelInfo.level,
      xpGained: xpAmount,
      statChanges,
    },
  };
}

export interface QuestTemplate {
  title: string;
  quest_type: string;
  xp_reward: number;
}

export function generateDailyQuests(profile: Profile): QuestTemplate[] {
  const quests: QuestTemplate[] = [
    { title: 'Complete today\'s workout', quest_type: 'workout', xp_reward: 100 },
    { title: `Drink ${profile.sleep_target_hours >= 7 ? '2.5L' : '2L'} water`, quest_type: 'water', xp_reward: 50 },
    { title: 'Walk 8,000 steps', quest_type: 'steps', xp_reward: 50 },
    { title: 'Study 90 minutes', quest_type: 'study', xp_reward: 75 },
    { title: `Sleep before 11:30 PM (${profile.sleep_target_hours}h target)`, quest_type: 'sleep', xp_reward: 50 },
  ];
  return quests;
}

export function checkBadgeEarned(workoutLogs: { date: string }[], dailyLogs: { workout_completed: boolean; date: string }[], profile: Profile): { badge_type: string; name: string; description: string; icon: string } | null {
  const workoutCount = workoutLogs.length;
  const streak = dailyLogs.filter(l => l.workout_completed).length;

  if (workoutCount >= 1 && !profile) return null;

  const badges: { threshold: number; badge_type: string; name: string; description: string; icon: string }[] = [
    { threshold: 1, badge_type: 'first_workout', name: 'First Workout', description: 'Completed your first workout', icon: '🏆' },
    { threshold: 7, badge_type: 'streak_7', name: '7-Day Streak', description: '7 consecutive days of training', icon: '🔥' },
    { threshold: 100, badge_type: 'workouts_100', name: '100 Workouts', description: 'Completed 100 workouts', icon: '💪' },
    { threshold: 30, badge_type: 'consistency_30', name: '30-Day Consistency', description: '30 days of consistency', icon: '⚡' },
  ];

  for (const badge of badges) {
    if (streak >= badge.threshold || workoutCount >= badge.threshold) {
      return badge;
    }
  }
  return null;
}

export function calculateProjectedWeight(currentWeight: number, consistencyScore: number, days: number): number {
  const weeklyLoss = (consistencyScore / 100) * 0.7;
  const projectedLoss = (weeklyLoss * days) / 7;
  return Math.round((currentWeight - projectedLoss) * 10) / 10;
}

export function calculateProjectedConsistency(currentConsistency: number, days: number): number {
  const improvement = Math.min(15, days * 0.1);
  return Math.min(100, Math.round(currentConsistency + improvement));
}
