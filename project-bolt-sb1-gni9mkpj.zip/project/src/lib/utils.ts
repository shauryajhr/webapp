export function cn(...classes: (string | false | undefined | null)[]): string {
  return classes.filter(Boolean).join(' ');
}

export function formatNumber(n: number): string {
  if (n >= 1_000_000) return (n / 1_000_000).toFixed(1) + 'M';
  if (n >= 1_000) return (n / 1_000).toFixed(1) + 'K';
  return Math.round(n).toString();
}

export function getGreeting(): string {
  const hour = new Date().getHours();
  if (hour < 12) return 'Good morning';
  if (hour < 18) return 'Good afternoon';
  return 'Good evening';
}

export function todayStr(): string {
  return new Date().toISOString().split('T')[0];
}

export function dateStr(daysAgo: number): string {
  const d = new Date();
  d.setDate(d.getDate() - daysAgo);
  return d.toISOString().split('T')[0];
}

export function xpForLevel(level: number): number {
  return level * 500 + (level - 1) * 250;
}

export function levelFromXp(xp: number): { level: number; xpIntoLevel: number; xpForNextLevel: number; progress: number } {
  let level = 1;
  let remaining = xp;
  while (remaining >= xpForLevel(level)) {
    remaining -= xpForLevel(level);
    level++;
  }
  const xpForNext = xpForLevel(level);
  return {
    level,
    xpIntoLevel: remaining,
    xpForNextLevel: xpForNext,
    progress: (remaining / xpForNext) * 100,
  };
}

export function levelTitle(level: number): string {
  if (level >= 50) return 'Beast Mode';
  if (level >= 30) return 'Elite';
  if (level >= 20) return 'Consistent';
  if (level >= 10) return 'Disciplined';
  if (level >= 5) return 'Starter';
  return 'Beginner';
}

export function getDayName(dayOfWeek: number): string {
  return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][dayOfWeek] || '';
}

export function getDayShort(dayOfWeek: number): string {
  return ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'][dayOfWeek] || '';
}

export function todayDayOfWeek(): number {
  return new Date().getDay();
}

export function calculateLifeLevel(stats: { strength: number; health: number; discipline: number; energy: number; consistency: number }): number {
  return Math.round(
    stats.strength * 0.25 +
    stats.health * 0.20 +
    stats.discipline * 0.20 +
    stats.energy * 0.15 +
    stats.consistency * 0.10 +
    ((stats.strength + stats.health + stats.discipline + stats.energy + stats.consistency) / 5) * 0.10
  );
}

export function calculateConsistencyScore(dailyLogs: { workout_completed: boolean; sleep_hours: number; water_liters: number; steps: number; daily_quests_completed: boolean }[]): number {
  if (dailyLogs.length === 0) return 0;
  let total = 0;
  for (const log of dailyLogs) {
    let score = 0;
    if (log.workout_completed) score += 25;
    if (log.sleep_hours >= 7) score += 20;
    if (log.water_liters >= 2) score += 20;
    if (log.steps >= 8000) score += 20;
    if (log.daily_quests_completed) score += 15;
    total += score;
  }
  return Math.round(total / dailyLogs.length);
}

export function getStreak(dailyLogs: { date: string; workout_completed: boolean }[]): number {
  const workoutDates = dailyLogs
    .filter(l => l.workout_completed)
    .map(l => l.date)
    .sort((a, b) => b.localeCompare(a));
  if (workoutDates.length === 0) return 0;
  let streak = 0;
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  for (let i = 0; i <= 365; i++) {
    const checkDate = new Date(today);
    checkDate.setDate(checkDate.getDate() - i);
    const dateStr = checkDate.toISOString().split('T')[0];
    if (workoutDates.includes(dateStr)) {
      streak++;
    } else if (i > 0) {
      break;
    }
  }
  return streak;
}
