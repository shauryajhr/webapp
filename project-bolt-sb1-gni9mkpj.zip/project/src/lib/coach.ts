import type { DailyLog, WorkoutLog, Profile, Goal } from '@/types';
import { getStreak, calculateConsistencyScore } from './utils';

export interface CoachInsight {
  insight: string;
  type: 'recovery' | 'progress' | 'warning' | 'motivation' | 'suggestion';
  priority: 'high' | 'medium' | 'low';
}

export function generateCoachInsights(
  dailyLogs: DailyLog[],
  workoutLogs: WorkoutLog[],
  profile: Profile,
  goals: Goal[],
): CoachInsight[] {
  const insights: CoachInsight[] = [];
  const last7 = dailyLogs.slice(-7);
  const last3 = dailyLogs.slice(-3);
  const streak = getStreak(dailyLogs.map(l => ({ date: l.date, workout_completed: l.workout_completed })));
  const consistencyScore = calculateConsistencyScore(last7);

  // Recovery insight
  const consecutiveWorkouts = last3.filter(l => l.workout_completed).length;
  if (consecutiveWorkouts >= 3) {
    insights.push({
      insight: `You've trained hard for ${consecutiveWorkouts} consecutive days. Today should be a recovery-focused day. Try light mobility work or a walk.`,
      type: 'recovery',
      priority: 'high',
    });
  }

  // Sleep insight
  const avgSleep = last7.length > 0 ? last7.reduce((s, l) => s + l.sleep_hours, 0) / last7.length : 0;
  if (avgSleep > 0 && avgSleep < profile.sleep_target_hours) {
    insights.push({
      insight: `Your average sleep is ${avgSleep.toFixed(1)}h, below your ${profile.sleep_target_hours}h target. Sleep is critical for muscle recovery and energy. Aim to sleep 30 minutes earlier tonight.`,
      type: 'warning',
      priority: 'high',
    });
  } else if (avgSleep >= profile.sleep_target_hours) {
    insights.push({
      insight: `Great sleep this week! Averaging ${avgSleep.toFixed(1)}h — that's above your target. Your recovery and energy should be optimal.`,
      type: 'progress',
      priority: 'low',
    });
  }

  // Consistency insight
  const prev7 = dailyLogs.slice(-14, -7);
  const prevConsistency = calculateConsistencyScore(prev7);
  if (prevConsistency > 0 && consistencyScore > prevConsistency) {
    const improvement = consistencyScore - prevConsistency;
    insights.push({
      insight: `Your workout consistency increased by ${improvement}% this month. You're on track to reach your goals. Keep pushing!`,
      type: 'progress',
      priority: 'medium',
    });
  } else if (consistencyScore < 50) {
    insights.push({
      insight: `Your consistency score is ${consistencyScore}/100. The #1 factor in reaching your goals is showing up. Even a 15-minute workout counts.`,
      type: 'suggestion',
      priority: 'high',
    });
  }

  // Streak motivation
  if (streak >= 5) {
    insights.push({
      insight: `${streak} day streak! You're building serious momentum. The hardest part was starting — now it's about not breaking the chain.`,
      type: 'motivation',
      priority: 'medium',
    });
  } else if (streak === 0 && workoutLogs.length > 0) {
    insights.push({
      insight: `Your streak was broken. That's okay — the best time to restart is today. Even a short workout will reignite your momentum.`,
      type: 'motivation',
      priority: 'medium',
    });
  }

  // Nutrition insight
  const avgProtein = last7.length > 0 ? last7.reduce((s, l) => s + l.protein_g, 0) / last7.length : 0;
  if (avgProtein > 0 && avgProtein < 100) {
    insights.push({
      insight: `Your protein intake averages ${Math.round(avgProtein)}g per day. For your goals, aim for at least 120-140g to support muscle recovery and growth.`,
      type: 'suggestion',
      priority: 'medium',
    });
  }

  // Water insight
  const avgWater = last7.length > 0 ? last7.reduce((s, l) => s + l.water_liters, 0) / last7.length : 0;
  if (avgWater > 0 && avgWater < 2) {
    insights.push({
      insight: `You're averaging ${avgWater.toFixed(1)}L of water. Hydration affects energy, performance, and recovery. Try keeping a water bottle visible throughout the day.`,
      type: 'suggestion',
      priority: 'low',
    });
  }

  // Goals insight
  const activeGoals = goals.filter(g => g.status === 'active');
  if (activeGoals.length > 0) {
    const closest = activeGoals.sort((a, b) => (b.current_value / b.target_value) - (a.current_value / a.target_value))[0];
    const progress = (closest.current_value / closest.target_value) * 100;
    if (progress >= 75) {
      insights.push({
        insight: `You're ${Math.round(progress)}% of the way to "${closest.title}". You're so close — push hard this week to finish strong!`,
        type: 'motivation',
        priority: 'high',
      });
    } else if (progress < 25) {
      insights.push({
        insight: `You're at ${Math.round(progress)}% on "${closest.title}". Break it down into daily actions — small steps compound fast.`,
        type: 'suggestion',
        priority: 'medium',
      });
    }
  }

  // Energy / mood insight
  const avgEnergy = last7.length > 0 ? last7.reduce((s, l) => s + l.energy_level, 0) / last7.length : 0;
  if (avgEnergy > 0 && avgEnergy <= 1.5) {
    insights.push({
      insight: `Your energy has been low this week. Consider an extra rest day, more sleep, or check your nutrition. Listen to your body.`,
      type: 'warning',
      priority: 'high',
    });
  }

  if (insights.length === 0) {
    insights.push({
      insight: `Welcome to LevelUp! Start by completing your first workout or logging today's activities to receive personalized coaching insights.`,
      type: 'motivation',
      priority: 'low',
    });
  }

  return insights;
}

export function generateMotivationalMessage(profile: Profile, streak: number, consistencyScore: number): string {
  const hour = new Date().getHours();
  const name = profile.name || 'Athlete';

  if (streak >= 10) {
    return `${name}, ${streak} days strong. You're not building a habit anymore — you're building a lifestyle. Keep going.`;
  }
  if (streak >= 5) {
    return `${name}, ${streak} day streak! Momentum is on your side. Today's workout will feel easier than day 1.`;
  }
  if (consistencyScore >= 80) {
    return `${name}, your consistency is elite (${consistencyScore}/100). This is what transformation looks like — one day at a time.`;
  }
  if (consistencyScore >= 50) {
    return `${name}, you're making progress. ${consistencyScore}/100 consistency. The gap between where you are and where you want to be is closer than you think.`;
  }
  if (hour < 12) {
    return `${name}, a new day means new XP. Start with something small — momentum builds from action, not motivation.`;
  }
  if (hour < 18) {
    return `${name}, the day isn't over yet. One workout, one healthy meal, one study session — any of these can turn today into a win.`;
  }
  return `${name}, reflect on today. Did you give your best? Tomorrow is another chance to level up. Rest well and come back stronger.`;
}
