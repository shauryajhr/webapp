import { supabase } from './supabase';
import type { Exercise } from '@/types';

const DEFAULT_WORKOUTS: { day_of_week: number; workout_type: string; title: string; exercises: Exercise[]; duration_min: number; difficulty: string; calories: number }[] = [
  {
    day_of_week: 1, workout_type: 'Push', title: 'Push Workout',
    exercises: [
      { name: 'Bench Press', sets: 4, reps: '8-10', weight_kg: 60, rest_sec: 90 },
      { name: 'Overhead Press', sets: 3, reps: '10-12', weight_kg: 40, rest_sec: 75 },
      { name: 'Incline Dumbbell Press', sets: 3, reps: '10-12', weight_kg: 22, rest_sec: 60 },
      { name: 'Tricep Dips', sets: 3, reps: '12-15', weight_kg: 0, rest_sec: 60 },
      { name: 'Lateral Raises', sets: 3, reps: '15-20', weight_kg: 8, rest_sec: 45 },
    ],
    duration_min: 50, difficulty: 'Intermediate', calories: 350,
  },
  {
    day_of_week: 2, workout_type: 'Cardio', title: 'Cardio + Mobility',
    exercises: [
      { name: 'Treadmill Run', sets: 1, reps: '30 min', weight_kg: 0, rest_sec: 0 },
      { name: 'Hip Mobility Flow', sets: 1, reps: '10 min', weight_kg: 0, rest_sec: 0 },
      { name: 'Foam Rolling', sets: 1, reps: '10 min', weight_kg: 0, rest_sec: 0 },
    ],
    duration_min: 50, difficulty: 'Easy', calories: 400,
  },
  {
    day_of_week: 3, workout_type: 'Pull', title: 'Pull Workout',
    exercises: [
      { name: 'Deadlift', sets: 4, reps: '6-8', weight_kg: 100, rest_sec: 120 },
      { name: 'Pull-ups', sets: 3, reps: '8-12', weight_kg: 0, rest_sec: 90 },
      { name: 'Barbell Row', sets: 3, reps: '10-12', weight_kg: 50, rest_sec: 75 },
      { name: 'Bicep Curls', sets: 3, reps: '12-15', weight_kg: 15, rest_sec: 60 },
      { name: 'Face Pulls', sets: 3, reps: '15-20', weight_kg: 20, rest_sec: 45 },
    ],
    duration_min: 50, difficulty: 'Intermediate', calories: 380,
  },
  {
    day_of_week: 4, workout_type: 'Recovery', title: 'Recovery & Stretch',
    exercises: [
      { name: 'Full Body Stretch', sets: 1, reps: '20 min', weight_kg: 0, rest_sec: 0 },
      { name: 'Yoga Flow', sets: 1, reps: '15 min', weight_kg: 0, rest_sec: 0 },
      { name: 'Meditation', sets: 1, reps: '10 min', weight_kg: 0, rest_sec: 0 },
    ],
    duration_min: 45, difficulty: 'Easy', calories: 120,
  },
  {
    day_of_week: 5, workout_type: 'Legs', title: 'Leg Day',
    exercises: [
      { name: 'Squats', sets: 4, reps: '8-10', weight_kg: 80, rest_sec: 120 },
      { name: 'Romanian Deadlift', sets: 3, reps: '10-12', weight_kg: 60, rest_sec: 90 },
      { name: 'Lunges', sets: 3, reps: '12 each leg', weight_kg: 20, rest_sec: 60 },
      { name: 'Leg Press', sets: 3, reps: '12-15', weight_kg: 120, rest_sec: 75 },
      { name: 'Calf Raises', sets: 4, reps: '15-20', weight_kg: 40, rest_sec: 45 },
    ],
    duration_min: 55, difficulty: 'Hard', calories: 450,
  },
  {
    day_of_week: 6, workout_type: 'Cardio', title: 'Cardio / Sports',
    exercises: [
      { name: 'Outdoor Run', sets: 1, reps: '5K', weight_kg: 0, rest_sec: 0 },
      { name: 'Sports Activity', sets: 1, reps: '30 min', weight_kg: 0, rest_sec: 0 },
    ],
    duration_min: 60, difficulty: 'Intermediate', calories: 500,
  },
  {
    day_of_week: 0, workout_type: 'Recovery', title: 'Full Recovery',
    exercises: [
      { name: 'Light Walk', sets: 1, reps: '30 min', weight_kg: 0, rest_sec: 0 },
      { name: 'Stretching', sets: 1, reps: '15 min', weight_kg: 0, rest_sec: 0 },
    ],
    duration_min: 45, difficulty: 'Easy', calories: 100,
  },
];

const DEFAULT_SCHEDULE: { day_of_week: number; time: string; title: string; category: string; duration_min: number; sort_order: number }[] = [
  { day_of_week: 1, time: '06:30', title: 'Wake Up', category: 'routine', duration_min: 30, sort_order: 0 },
  { day_of_week: 1, time: '07:00', title: 'Morning Walk', category: 'fitness', duration_min: 30, sort_order: 1 },
  { day_of_week: 1, time: '08:00', title: 'Breakfast', category: 'nutrition', duration_min: 30, sort_order: 2 },
  { day_of_week: 1, time: '09:00', title: 'Work / Study', category: 'productivity', duration_min: 240, sort_order: 3 },
  { day_of_week: 1, time: '13:00', title: 'Lunch', category: 'nutrition', duration_min: 60, sort_order: 4 },
  { day_of_week: 1, time: '17:00', title: 'Push Workout', category: 'fitness', duration_min: 50, sort_order: 5 },
  { day_of_week: 1, time: '19:00', title: 'Study Session', category: 'productivity', duration_min: 120, sort_order: 6 },
  { day_of_week: 1, time: '21:00', title: 'Dinner', category: 'nutrition', duration_min: 45, sort_order: 7 },
  { day_of_week: 1, time: '23:00', title: 'Sleep', category: 'recovery', duration_min: 480, sort_order: 8 },
];

const DEFAULT_HABITS: { name: string; icon: string; frequency: string; target_count: number }[] = [
  { name: 'Drink 2L Water', icon: '💧', frequency: 'daily', target_count: 1 },
  { name: 'Read 30 min', icon: '📚', frequency: 'daily', target_count: 1 },
  { name: 'Meditate', icon: '🧘', frequency: 'daily', target_count: 1 },
  { name: 'No Sugar', icon: '🚫', frequency: 'daily', target_count: 1 },
  { name: 'Cold Shower', icon: '🚿', frequency: 'daily', target_count: 1 },
];

function randomBetween(min: number, max: number): number {
  return Math.random() * (max - min) + min;
}

export async function seedDemoData(userId: string, weightKg: number) {
  // Seed workouts
  const workoutRows = DEFAULT_WORKOUTS.map(w => ({ user_id: userId, ...w, exercises: JSON.stringify(w.exercises) }));
  await supabase.from('workouts').upsert(workoutRows, { onConflict: 'user_id,day_of_week' }).eq('user_id', userId);

  // Seed daily logs for last 30 days
  const dailyLogRows: Record<string, unknown>[] = [];
  for (let i = 29; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().split('T')[0];
    const didWorkout = Math.random() > 0.3;
    dailyLogRows.push({
      user_id: userId,
      date: dateStr,
      steps: Math.floor(randomBetween(4000, 12000)),
      water_liters: +(randomBetween(1, 3)).toFixed(1),
      sleep_hours: +(randomBetween(5.5, 8.5)).toFixed(1),
      calories_eaten: Math.floor(randomBetween(1600, 2400)),
      protein_g: Math.floor(randomBetween(80, 160)),
      carbs_g: Math.floor(randomBetween(150, 300)),
      fats_g: Math.floor(randomBetween(40, 90)),
      energy_level: Math.floor(randomBetween(1, 4)),
      mood: Math.floor(randomBetween(2, 6)),
      stress_level: Math.floor(randomBetween(1, 4)),
      study_hours: +(randomBetween(0, 3)).toFixed(1),
      screen_time_hours: +(randomBetween(2, 7)).toFixed(1),
      meditation_minutes: Math.random() > 0.5 ? Math.floor(randomBetween(5, 30)) : 0,
      workout_completed: didWorkout,
      daily_quests_completed: Math.random() > 0.5,
    });
  }
  await supabase.from('daily_logs').upsert(dailyLogRows, { onConflict: 'user_id,date' }).eq('user_id', userId);

  // Seed workout logs (matching days where workout was completed)
  const { data: logs } = await supabase.from('daily_logs').select('date, workout_completed').eq('user_id', userId);
  const workoutDates = (logs || []).filter((l: { workout_completed: boolean }) => l.workout_completed).map((l: { date: string }) => l.date);
  const workoutLogRows: Record<string, unknown>[] = [];
  const workoutTypes = ['Push', 'Pull', 'Legs', 'Cardio', 'Recovery'];
  workoutDates.forEach((date: string, i: number) => {
    workoutLogRows.push({
      user_id: userId,
      date,
      workout_type: workoutTypes[i % workoutTypes.length],
      exercises_completed: JSON.stringify([]),
      duration_min: Math.floor(randomBetween(30, 60)),
      calories_burned: Math.floor(randomBetween(200, 500)),
      xp_earned: 100,
    });
  });
  await supabase.from('workout_logs').upsert(workoutLogRows).eq('user_id', userId);

  // Seed body metrics — weight declining slightly over time
  const bodyRows: Record<string, unknown>[] = [];
  let w = weightKg + 3;
  for (let i = 29; i >= 0; i -= 3) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    w -= randomBetween(0.1, 0.4);
    bodyRows.push({
      user_id: userId,
      date: d.toISOString().split('T')[0],
      weight_kg: +w.toFixed(1),
      pushups_max: Math.floor(randomBetween(15, 35)),
    });
  }
  await supabase.from('body_metrics').upsert(bodyRows, { onConflict: 'user_id,date' }).eq('user_id', userId);

  // Seed schedule (for all weekdays — copy Monday template to each day)
  const scheduleRows: Record<string, unknown>[] = [];
  for (let day = 0; day < 7; day++) {
    DEFAULT_SCHEDULE.forEach(item => {
      scheduleRows.push({ user_id: userId, ...item, day_of_week: day });
    });
  }
  await supabase.from('schedule_items').upsert(scheduleRows).eq('user_id', userId);

  // Seed habits
  const habitRows = DEFAULT_HABITS.map(h => ({ user_id: userId, ...h }));
  await supabase.from('habits').upsert(habitRows).eq('user_id', userId);

  // Seed goals
  const goalRows: Record<string, unknown>[] = [
    { user_id: userId, type: 'weight', title: 'Lose 5 KG', target_value: 5, current_value: 2.5, unit: 'kg', deadline: new Date(Date.now() + 60 * 86400000).toISOString().split('T')[0], status: 'active', streak: 12 },
    { user_id: userId, type: 'running', title: 'Run 5 KM', target_value: 5, current_value: 3.2, unit: 'km', deadline: new Date(Date.now() + 30 * 86400000).toISOString().split('T')[0], status: 'active', streak: 5 },
    { user_id: userId, type: 'frequency', title: 'Workout 4x per week', target_value: 4, current_value: 3, unit: 'workouts/week', deadline: null, status: 'active', streak: 8 },
    { user_id: userId, type: 'study', title: 'Study 2 hours daily', target_value: 2, current_value: 1.5, unit: 'hours/day', deadline: null, status: 'active', streak: 6 },
    { user_id: userId, type: 'sleep', title: 'Sleep 7+ hours', target_value: 7, current_value: 6.8, unit: 'hours', deadline: null, status: 'active', streak: 4 },
    { user_id: userId, type: 'pushups', title: '50 Push-ups in one set', target_value: 50, current_value: 28, unit: 'pushups', deadline: new Date(Date.now() + 45 * 86400000).toISOString().split('T')[0], status: 'active', streak: 0 },
  ];
  await supabase.from('goals').upsert(goalRows).eq('user_id', userId);

  // Seed badges
  const badgeRows: Record<string, unknown>[] = [
    { user_id: userId, badge_type: 'first_workout', name: 'First Workout', description: 'Completed your first workout', icon: '🏆' },
    { user_id: userId, badge_type: 'streak_7', name: '7-Day Streak', description: '7 consecutive days of training', icon: '🔥' },
    { user_id: userId, badge_type: 'consistency_30', name: '30-Day Consistency', description: '30 days of tracking', icon: '⚡' },
    { user_id: userId, badge_type: 'first_5k', name: 'First 5K', description: 'Ran your first 5K', icon: '🏃' },
    { user_id: userId, badge_type: 'perfect_week', name: '100% Week', description: 'Completed all quests for a week', icon: '💯' },
  ];
  await supabase.from('badges').upsert(badgeRows).eq('user_id', userId);

  // Update profile with computed stats
  const workoutCount = workoutDates.length;
  const xp = 1500 + workoutCount * 100 + Math.floor(randomBetween(200, 500));
  const level = Math.floor(xp / 750) + 1;
  const strength = Math.min(100, 30 + workoutCount * 2);
  const health = Math.min(100, 35 + Math.floor(randomBetween(20, 35)));
  const discipline = Math.min(100, 25 + workoutCount * 2);
  const energy = Math.min(100, 40 + Math.floor(randomBetween(20, 35)));
  const consistency = Math.min(100, 30 + workoutCount * 3);
  const life_level = Math.round(strength * 0.25 + health * 0.20 + discipline * 0.20 + energy * 0.15 + consistency * 0.10 + ((strength + health + discipline + energy + consistency) / 5) * 0.10);

  await supabase.from('profiles').update({
    xp, level, strength, health, discipline, energy, consistency, life_level,
  }).eq('id', userId);

  // Seed today's quests
  const todayDate = new Date().toISOString().split('T')[0];
  const questRows: Record<string, unknown>[] = [
    { user_id: userId, date: todayDate, title: "Complete today's workout", quest_type: 'workout', xp_reward: 100, completed: false },
    { user_id: userId, date: todayDate, title: 'Drink 2.5L water', quest_type: 'water', xp_reward: 50, completed: false },
    { user_id: userId, date: todayDate, title: 'Walk 8,000 steps', quest_type: 'steps', xp_reward: 50, completed: false },
    { user_id: userId, date: todayDate, title: 'Study 90 minutes', quest_type: 'study', xp_reward: 75, completed: false },
    { user_id: userId, date: todayDate, title: 'Sleep before 11:30 PM', quest_type: 'sleep', xp_reward: 50, completed: false },
  ];
  await supabase.from('quests').upsert(questRows).eq('user_id', userId);
}
