import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.tsx';
import Downloads from './pages/Downloads.tsx';
import './index.css';

const isDownloadsPage = window.location.pathname === '/downloads';

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    {isDownloadsPage ? <Downloads /> : <App />}
  </StrictMode>
);
